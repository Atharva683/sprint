package com.setup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import com.parameters.WaitUtils;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.TimeoutException;

public abstract class BasePage {
    protected WebDriver driver;
    protected WaitUtils wait;

    public BasePage(WebDriver driver){
        this.driver = driver;
        this.wait = new WaitUtils(driver, 20);
        PageFactory.initElements(driver, this);
    }

    protected void click(WebElement element){
        wait.waitForClickable(element);
        element.click();
    }

    protected void sendKeys(WebElement element, String text){
        wait.waitForVisible(element);
        element.clear();
        element.sendKeys(text);
    }

    protected String getText(WebElement element){
        wait.waitForVisible(element);
        return element.getText();
    }

    protected void safeClick(WebElement element){
        try { click(element); } catch(Exception e){ try { element.click(); } catch(Exception ex){} }
    }

    protected String getLocatorInfo(WebElement element){
        try { return element.toString(); } catch(Exception e){ return "unknown"; }
    }
}
