package com.parameters;
 
import java.io.FileInputStream;

import java.io.IOException;

import java.util.Properties;

public class ConfigReader {

    private static Properties properties;

    static {

        try {

            properties = new Properties();

            FileInputStream fis = new FileInputStream("src/test/resources/PropertieFiles/profile.properties");

//            FileInputStream fis1 = new FileInputStream("src/test/resources/PropertieFiles/MagicBricks.properties");

            properties.load(fis);

//            properties.load(fis1);

        } catch (IOException e) {

            throw new RuntimeException("profile.properties file NOT FOUND at specified path!");

        }

    }

    public static String getProperty(String key) {

        String value = properties.getProperty(key);

        if (value == null) {

            System.err.println("Property key '" + key + "' not found in profile.properties");

            return "";

        }

        return value;

    }

}
 