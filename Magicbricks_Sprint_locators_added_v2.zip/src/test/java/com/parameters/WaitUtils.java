package com.parameters;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class WaitUtils {
    private final WebDriver driver;
    private final WebDriverWait wait;

    public WaitUtils(WebDriver driver, int seconds){
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
    }

    public void waitForVisible(WebElement element){
        try { wait.until(ExpectedConditions.visibilityOf(element)); } catch(TimeoutException e){ throw e; }
    }

    public void waitForClickable(WebElement element){
        try { wait.until(ExpectedConditions.elementToBeClickable(element)); } catch(TimeoutException e){ throw e; }
    }

    public void waitForClickable(By locator){
        wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    public void waitForVisible(By locator){
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public void waitForPageLoad(){
        wait.until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));
    }
}
