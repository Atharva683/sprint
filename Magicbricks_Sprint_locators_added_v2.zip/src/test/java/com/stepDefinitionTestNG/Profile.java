package com.stepDefinitionTestNG;

import com.setup.DriverManager;
import com.pages.*;
import com.parameters.ConfigReader;
import com.parameters.ExcelUtils;

import io.cucumber.java.en.*;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class Profile {
    private WebDriver driver = DriverManager.getDriver();
    private HomePage home = new HomePage(driver);
    private FormFillPage form = new FormFillPage(driver);
    private DesignersListingPage listing = new DesignersListingPage(driver);
    private DesignerProfilePage profile = new DesignerProfilePage(driver);
    private EstimationPage estimation = new EstimationPage(driver);
    private SelectAndBookPage selectAndBook = new SelectAndBookPage(driver);

    @When("I hover over Home Interiors")
    public void i_hover_over_home_interiors() {
        home.hoverHomeInteriors();
    }

    @When("I click on Home interior design services")
    public void i_click_on_home_interior_design_services() {
        home.clickInteriorServices();
    }

    @When("I fill in the form with detail at <rowNum> in \"Data\"")
    public void i_fill_in_the_form_with_detail_at_rowNum_in_data() throws Exception {
        // read first row by default
        ExcelUtils xu = new ExcelUtils(System.getProperty("user.dir")+"/src/test/resources/ExcelData/Data.xlsx");
        Map<String,String> data = xu.readRowAsMap("Data",1);
        form.fillContact(data.getOrDefault("FullName",""), data.getOrDefault("PhoneNumber",""), data.getOrDefault("City",""));
    }

    @When("I click on Book Slot")
    public void i_click_on_book_slot() {
        form.clickBookSlot();
    }

    @Then("I wait for OTP entry")
    public void i_wait_for_otp_entry() {
        Assert.assertTrue(form.isOtpVisible());
    }

    @When("I manually enter the OTP and click Submit")
    public void i_manually_enter_the_otp_and_click_submit() {
        form.submitOtpIfPresent();
    }

    @Then("I should be navigated to the budget selection page")
    public void i_should_be_navigated_to_budget_selection() {
        // best-effort: check presence of budget options
        // Handled in following steps
    }

    @When("I select Possesion status and Budget from excel <rowNum>")
    public void i_select_possesion_status_and_budget_from_excel_rowNum() throws Exception {
        ExcelUtils xu = new ExcelUtils(System.getProperty("user.dir")+"/src/test/resources/ExcelData/Data.xlsx");
        Map<String,String> data = xu.readRowAsMap("Data",1);
        form.selectPossession(data.getOrDefault("Possession",""));
        form.selectBudget(data.getOrDefault("Budget",""));
    }

    @When("I click on Submit")
    public void i_click_on_submit() {
        form.clickBookSlot();
    }

    @Then("I should be navigated to the designer listing page")
    public void i_should_be_on_designer_listing() {
        // placeholder - navigation validated by subsequent steps
    }

    @When("I click on \"Explore Top Interior Designers near you\"")
    public void i_click_on_explore_top_interior_designers_near_you() {
        home.clickExploreDesigners();
    }

    @When("I apply filters for city \"{string}\" and budget \"{string}\"")
    public void i_apply_filters_for_city_and_budget(String city, String budget) {
        listing.scrollToDesignerList();
        listing.applyCity(city);
        listing.applyBudget(budget);
    }

    @Then("the designer list should update based on filters")
    public void the_designer_list_should_update_based_on_filters() {
        Assert.assertTrue(listing.hasResults());
    }

    @When("I select the first designer from the filtered results")
    public void i_select_the_first_designer_from_the_filtered_results() {
        listing.selectFirstDesigner();
    }

    @Then("I should be navigated to the designer profile page")
    public void i_should_be_navigated_to_designer_profile() {
        Assert.assertTrue(profile.isProfileDetailsVisible());
    }

    @When("I click on \"Book a Visit\"")
    public void i_click_on_book_a_visit() {
        profile.clickBookVisit();
    }

    @Then("the booking confirmation should appear")
    public void the_booking_confirmation_should_appear() {
        Assert.assertTrue(profile.isBookingConfirmed());
    }
}
