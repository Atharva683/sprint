package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;

/**
 * HomePage with exact locators provided
 */
public class HomePage extends BasePage {

    @FindBy(xpath = "//a[normalize-space()='Home Interiors']") private WebElement homeInteriorsTab;
    @FindBy(xpath = "//a[normalize-space()='Home Interior Design Services']") private WebElement interiorServicesLink;
    @FindBy(css = ".expo-regular-thx__cta") private WebElement exploreDesignersBtn;

    public HomePage(WebDriver driver){ super(driver); }

    public void hoverHomeInteriors(){
        try { new Actions(driver).moveToElement(homeInteriorsTab).pause(java.time.Duration.ofMillis(300)).perform(); } catch(Exception e){}
    }

    public void clickInteriorServices(){
        try { interiorServicesLink.click(); } catch(Exception e){ ((JavascriptExecutor)driver).executeScript("arguments[0].click();", interiorServicesLink); }
    }

    public void clickExploreDesigners(){
        try { exploreDesignersBtn.click(); } catch(Exception e){ ((JavascriptExecutor)driver).executeScript("arguments[0].click();", exploreDesignersBtn); }
    }
}
