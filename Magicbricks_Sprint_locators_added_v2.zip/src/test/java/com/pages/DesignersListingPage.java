package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;

/**
 * DesignersListingPage with exact locators
 */
public class DesignersListingPage extends BasePage {
    @FindBy(css = ".int-city__item.has-dropdown.has-selected, .int-city__item.has-selected") private WebElement citySelected;
    @FindBy(css = ".intsrp__card--heading") private List<WebElement> designerNames;
    @FindBy(css = ".intsrp__card--heading, .designer-card, .intsrp__card") private List<WebElement> designerItems;
    @FindBy(xpath = "//span[contains(@class,'intsrp__card__actions--cta') and contains(.,'Book')]") private WebElement bookVisitSpan;

    public DesignersListingPage(WebDriver driver){ super(driver); }

    public void applyCity(String city){
        try{ driver.findElement(By.xpath("//div[contains(@class,'int-city__item') and contains(.,'"+city+"')]")).click(); } catch(Exception e){} 
    }

    public void applyBudget(String budget){
        try{ driver.findElement(By.xpath("//label[contains(.,'"+budget+"')]")).click(); } catch(Exception e){} 
    }

    public void scrollToDesignerList(){
        try{ if(designerItems!=null && !designerItems.isEmpty()) ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", designerItems.get(0)); } catch(Exception e){}
    }

    public boolean hasResults(){ try{ return designerItems!=null && !designerItems.isEmpty(); } catch(Exception e){ return false; } }

    public void selectFirstDesigner(){ try{ if(designerItems!=null && !designerItems.isEmpty()) designerItems.get(0).click(); } catch(Exception e){} }
}
