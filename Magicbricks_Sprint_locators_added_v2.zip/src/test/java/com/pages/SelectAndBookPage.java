package com.pages;
import org.openqa.selenium.WebDriver;

public class SelectAndBookPage extends BasePage {
    public SelectAndBookPage(WebDriver driver){ super(driver); }

    public void selectDesignerAndBook(String city, String budget){
        DesignersListingPage dl = new DesignersListingPage(driver);
        dl.applyCity(city);
        dl.applyBudget(budget);
        dl.scrollToDesignerList();
        dl.selectFirstDesigner();
        DesignerProfilePage dp = new DesignerProfilePage(driver);
        dp.clickBookVisit();
    }
}
