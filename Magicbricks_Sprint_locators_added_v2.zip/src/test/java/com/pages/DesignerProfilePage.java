package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.JavascriptExecutor;

/**
 * DesignerProfilePage with exact locators
 */
public class DesignerProfilePage extends BasePage {
    @FindBy(css = "h2.intsrp__card--heading") private WebElement designerHeading;
    @FindBy(css = ".intsrp__card__actions--cta.contact, span.intsrp__card__actions--cta.contact, span.contact") private WebElement bookVisitBtn;
    @FindBy(css = ".booking-confirmation, .confirmation-message, .success-msg") private WebElement bookingConfirmation;
    @FindBy(css = ".rating, .designer-rating") private WebElement rating;
    @FindBy(css = ".experience, .designer-experience") private WebElement experience;
    @FindBy(css = ".price-range, .designer-price") private WebElement priceRange;

    public DesignerProfilePage(WebDriver driver){ super(driver); }

    public boolean isProfileDetailsVisible(){ try{ return designerHeading.isDisplayed() && rating.isDisplayed() && experience.isDisplayed() && priceRange.isDisplayed(); } catch(Exception e){ return false; } }

    public void clickBookVisit(){ try{ bookVisitBtn.click(); } catch(Exception e){ ((JavascriptExecutor)driver).executeScript("arguments[0].click();", bookVisitBtn); } }

    public boolean isBookingConfirmed(){ try{ return bookingConfirmation.isDisplayed(); } catch(Exception e){ return false; } }
}
