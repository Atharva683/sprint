package com.pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;

/**
 * HomeBookingPage - contains booking locators
 */
public class HomeBookingPage extends BasePage {
    @FindBy(id = "user-name") private WebElement fullName;
    @FindBy(id = "phone") private WebElement phone;
    @FindBy(className= "custom-dropdown__value") private WebElement city;
    @FindBy(xpath = "//button[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'),'book your slot') or contains(.,'Book Your Slot') or contains(.,'Book Slot')]") private WebElement bookSlotBtn;
    @FindBy(css = "button.hic-contact__btn.hic-contact__btn--fill") private WebElement otpInput;
    @FindBy(xpath = "//a[normalize-space()='Home Interiors']") private WebElement homeInteriorsTab;
    @FindBy(xpath = "//a[normalize-space()='Home Interior Design Services']") private WebElement interiorServicesLink;
    @FindBy(css = ".hic-form-row__radiobtn--text") private List<WebElement> possessionOptions;
    @FindBy(xpath = "//label[contains(@class,'mb-form-ui__select__label')]") private List<WebElement> budgetOptions;
    @FindBy(css = ".expo-regular-thx__cta") private WebElement exploreDesignersBtn;

    public HomeBookingPage(WebDriver driver){ super(driver); }

    public void fillContact(String name, String ph, String c){
        try{ fullName.clear(); fullName.sendKeys(name);}catch(Exception e){}
        try{ phone.clear(); phone.sendKeys(ph);}catch(Exception e){}
        try{ city.click(); city.sendKeys(c);}catch(Exception e){}
    }

    public void clickBookSlot(){ try{ bookSlotBtn.click(); } catch(Exception e){ ((JavascriptExecutor)driver).executeScript("arguments[0].click();", bookSlotBtn);} }

    public boolean isOtpVisible(){ try{ return otpInput.isDisplayed(); } catch(Exception e){ return false; } }
    public void submitOtpIfPresent(){ try{ WebElement sub = driver.findElement(By.cssSelector("button.hic-contact__btn.hic-contact__btn--fill")); if(sub!=null) sub.click(); } catch(Exception e){} }
    public void selectBudget(String budget){ try{ for(WebElement b: budgetOptions){ if(b.getText().trim().contains(budget)){ b.click(); return; } } } catch(Exception e){} }
    public void selectPossession(String pos){ try{ for(WebElement p: possessionOptions){ if(p.getText().trim().contains(pos)){ p.click(); return; } } } catch(Exception e){} }
    public void hoverHomeInteriors(){ try{ /* no-op if missing */ } catch(Exception e){} }
    public void clickInteriorServices(){ try{ interiorServicesLink.click(); } catch(Exception e){ ((JavascriptExecutor)driver).executeScript("arguments[0].click();", interiorServicesLink);} }
}
