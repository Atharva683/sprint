package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

/**
 * EstimationPage with exact locators
 */
public class EstimationPage extends BasePage {

    @FindBy(css = "a.mb-button--btn.btn-red.large, a.mb-button--btn.btn-red") private WebElement getQuoteBtn;
    @FindBy(xpath = "//div[contains(@class,'radioCard__content--data')]//div[contains(.,'2 BHK') or contains(.,'BHK')]") private WebElement bhkOption;
    @FindBy(css = ".kwpe__layout__card--area") private WebElement sizeOption;
    @FindBy(xpath = "//label[contains(@class,'mb-form-ui__select__label') and contains(.,'Within 2 Months')]") private WebElement timelineOption;
    @FindBy(xpath = "//label[contains(@class,'mb-form-ui__select__label') and (contains(.,'3 to 5 Lacs') or contains(.,'3 - 5 Lakhs'))]") private WebElement budgetOptionLabel;
    @FindBy(xpath = "//label[contains(@class,'mb-form-ui__select__label') and contains(.,'Self-use')]") private WebElement purposeOption;
    @FindBy(css = "button.cta.cta-filled") private WebElement continueBtn;
    @FindBy(css = "button.btn.btn-filled") private WebElement emailEstimateBtn;
    @FindBy(css = "span.close") private WebElement closeBtn;

    public EstimationPage(WebDriver driver){ super(driver); }

    public void startEstimation(){ try{ getQuoteBtn.click(); } catch(Exception e){ try{ driver.findElement(By.xpath("//a[contains(.,'Get Quote')]")).click(); } catch(Exception ex){} } }

    public void selectBhkAndSize(String bhk, String size){
        try{ bhkOption.click(); } catch(Exception e){}
        try{ sizeOption.click(); } catch(Exception e){}
    }

    public void provideAdditionalDetails(String timeline, String budget, String purpose){
        try{ timelineOption.click(); } catch(Exception e){} 
        try{ budgetOptionLabel.click(); } catch(Exception e){} 
        try{ purposeOption.click(); } catch(Exception e){} 
    }

    public void submitEstimation(){ try{ continueBtn.click(); } catch(Exception e){} }
}
