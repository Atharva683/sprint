package com.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/test/resources/Features/InteriorDesign.feature", glue = {"com.stepDefinitionTestNG"}, plugin = {"pretty", "json:target/Json/cucumber.json", "html:target/Reports/CucumberReport.html"}, monochrome = true)
public class TestRunnerTestNG extends AbstractTestNGCucumberTests {
}
