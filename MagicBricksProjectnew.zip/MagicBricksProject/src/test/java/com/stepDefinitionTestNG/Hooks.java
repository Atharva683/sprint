package com.stepDefinitionTestNG;


import com.setup.DriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
 
public class Hooks {
	public Hooks() {}

	@Before
	public void setup(Scenario scenario) {
		System.out.println("=============== [BEFORE SCENARIO] ===============");
		System.out.println("Starting Scenario: " + scenario.getName());
		WebDriver driver = DriverManager.getDriver();
		driver.manage().window().maximize();
		driver.get("https://www.magicbricks.com");
		System.out.println("Browser launched and pages initialized");
	}
 
	@After
	public void teardown(Scenario scenario) {
		System.out.println("=============== [AFTER SCENARIO] ===============");
		System.out.println("Finished Scenario: " + scenario.getName() + " | Status: " + scenario.getStatus());
		WebDriver driver = null;
		try {
			driver = DriverManager.getDriver();
		} catch (Exception e) {
			System.err.println("Driver not available during teardown: " + e.getMessage());
		}
		if (driver != null && scenario.isFailed()) {
			try {
				By errorMessage = By.xpath("//p[contains(@class,'oxd-alert-content-text')]");
				if (driver.findElements(errorMessage).size() > 0) {
					String message = driver.findElement(errorMessage).getText();
					System.out.println("Captured error message: " + message);
				}
				final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
				scenario.attach(screenshot, "image/png", "Failure Screenshot");
				String screenshotDir = "screenshots";
				Files.createDirectories(Paths.get(screenshotDir)); // Create folder if it doesn't exist
				String fileName = screenshotDir + "/" + scenario.getName().replaceAll("[^a-zA-Z0-9]", "_") + ".png";
				try (FileOutputStream out = new FileOutputStream(new File(fileName))) {
					out.write(screenshot);
				}
				System.out.println("Screenshot saved to: " + fileName);
			} catch (Exception e) {
				System.out.println("No error message or screenshot available: " + e.getMessage());
			}
		}
		DriverManager.quitDriver();
		System.out.println("Browser closed");
	}
}

 