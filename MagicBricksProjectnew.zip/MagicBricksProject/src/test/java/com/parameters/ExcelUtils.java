package com.parameters;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExcelUtils {

    private Workbook workbook;
    private Sheet sheet;
    private DataFormatter dataFormatter;
    private String filePath;

    // Constructor: Load workbook and sheet
    public ExcelUtils(String filePath, String sheetName) throws IOException {
        this.filePath = filePath;
        try (FileInputStream fis = new FileInputStream(filePath)) {
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheet(sheetName);
            dataFormatter = new DataFormatter();
        } catch (IOException e) {
            throw new IOException("Failed to load Excel file: " + filePath, e);
        }
    }

    //  Read a single cell value
    public String getCellData(int rowNum, int colNum) {
        Row row = sheet.getRow(rowNum);
        if (row == null) return "";
        Cell cell = row.getCell(colNum);
        if (cell == null) return "";
        return dataFormatter.formatCellValue(cell);
    }

    //  Read all cell values from a row
    public List<String> getRowData(int rowNum) {
        List<String> rowData = new ArrayList<>();
        Row row = sheet.getRow(rowNum);
        if (row == null) return rowData;
        for (int i = 0; i < row.getLastCellNum(); i++) {
            rowData.add(getCellData(rowNum, i));
        }
        return rowData;
    }

    //  Write data to a cell
    public void setCellData(String value, int rowNum, int colNum) {
        Row row = sheet.getRow(rowNum);
        if (row == null) row = sheet.createRow(rowNum);
        Cell cell = row.getCell(colNum);
        if (cell == null) cell = row.createCell(colNum);
        cell.setCellValue(value);
    }

    //  Save changes to the Excel file
    public void saveChanges() throws IOException {
        try (FileOutputStream fos = new FileOutputStream(filePath)) {
            workbook.write(fos);
        }
    }

    //  Close the workbook
    public void closeWorkbook() throws IOException {
        if (workbook != null) {
            workbook.close();
        }
    }

    //  Get row count
    public int getRowCount() {
        return sheet.getPhysicalNumberOfRows();
    }

    //  Get column count for a row
    public int getColumnCount(int rowNum) {
        Row row = sheet.getRow(rowNum);
        return (row != null) ? row.getLastCellNum() : 0;
    }
    
    public Map<String, String> getRowAsMap(int rowNum) {
        Map<String, String> rowMap = new HashMap<>();
        Row headerRow = sheet.getRow(0); // first row = headers
        Row dataRow = sheet.getRow(rowNum);
        if (headerRow == null || dataRow == null) return rowMap;

        int colCount = headerRow.getLastCellNum();
        for (int i = 0; i < colCount; i++) {
            String key = dataFormatter.formatCellValue(headerRow.getCell(i));
            String value = dataFormatter.formatCellValue(dataRow.getCell(i));
            rowMap.put(key, value);
        }
        return rowMap;
    }

    public void setCellDataByColumnName(String value, int rowNum, String colName) {
        Row headerRow = sheet.getRow(0); // header row
        if (headerRow == null) {
            throw new RuntimeException("Header row not found in sheet");
        }

        int colIndex = -1;
        for (int i = 0; i < headerRow.getLastCellNum(); i++) {
            String header = dataFormatter.formatCellValue(headerRow.getCell(i));
            if (header.equalsIgnoreCase(colName)) {
                colIndex = i;
                break;
            }
        }

        if (colIndex == -1) {
            throw new RuntimeException("Column '" + colName + "' not found in sheet");
        }

        setCellData(value, rowNum, colIndex);
    }

}