package com.parameters;

public class ReviewData {
    // ⭐ Overall rating stored as numeric stars (1–5)
    private int overallRating;

    private int locationRating;
    private int staffBehaviorRating;
    private int cleanlinessRating;
    private int foodRating;
    private int wifiRating;

    private String currentStatus;
    private String reviewText;

    // ===== Getters & Setters =====
    public int getOverallRating() { return overallRating; }
    public void setOverallRating(int overallRating) { this.overallRating = overallRating; }

    public int getLocationRating() { return locationRating; }
    public void setLocationRating(int locationRating) { this.locationRating = locationRating; }

    public int getStaffBehaviorRating() { return staffBehaviorRating; }
    public void setStaffBehaviorRating(int staffBehaviorRating) { this.staffBehaviorRating = staffBehaviorRating; }

    public int getCleanlinessRating() { return cleanlinessRating; }
    public void setCleanlinessRating(int cleanlinessRating) { this.cleanlinessRating = cleanlinessRating; }

    public int getFoodRating() { return foodRating; }
    public void setFoodRating(int foodRating) { this.foodRating = foodRating; }

    public int getWifiRating() { return wifiRating; }
    public void setWifiRating(int wifiRating) { this.wifiRating = wifiRating; }

    public String getCurrentStatus() { return currentStatus; }
    public void setCurrentStatus(String currentStatus) { this.currentStatus = currentStatus; }

    public String getReviewText() { return reviewText; }
    public void setReviewText(String reviewText) { this.reviewText = reviewText; }
}
