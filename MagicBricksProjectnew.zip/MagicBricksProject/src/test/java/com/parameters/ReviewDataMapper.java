package com.parameters;

import java.io.IOException;
import java.util.Map;

public class ReviewDataMapper {

    public static ReviewData fromExcel(String filePath, String sheetName, int rowNum) throws IOException {
        ExcelUtils excel = new ExcelUtils(filePath, sheetName);
        Map<String, String> row = excel.getRowAsMap(rowNum);

        ReviewData data = new ReviewData();

        // Overall rating: Excel may store text (e.g., "Good", "Average") or numeric
        String overallCell = row.get("OverallRating");
        int overallStars;
        try {
            // Try parsing as number first
            overallStars = Integer.parseInt(overallCell);
        } catch (NumberFormatException e) {
            // If not numeric, map text to stars
            overallStars = mapOverallRating(overallCell);
        }
        data.setOverallRating(overallStars);

        // Parse numeric ratings directly
        data.setLocationRating(Integer.parseInt(row.get("LocationRating")));
        data.setStaffBehaviorRating(Integer.parseInt(row.get("StaffBehaviorRating")));
        data.setCleanlinessRating(Integer.parseInt(row.get("CleanlinessRating")));
        data.setFoodRating(Integer.parseInt(row.get("FoodRating")));
        data.setWifiRating(Integer.parseInt(row.get("WifiRating")));

        // Text fields
        data.setCurrentStatus(row.get("CurrentStatus"));
        data.setReviewText(row.get("ReviewText"));

        excel.closeWorkbook();
        return data;
    }

    // Helper to map text to numeric stars
    private static int mapOverallRating(String text) {
        if (text == null) return 3; // default
        switch (text.toLowerCase().trim()) {
            case "excellent": return 5;
            case "good": return 4;
            case "average": return 3;
            case "poor": return 2;
            case "bad": return 1;
            default: return 3;
        }
    }
}
