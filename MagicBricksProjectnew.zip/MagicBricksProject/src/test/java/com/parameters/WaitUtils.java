package com.parameters;
 
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
 
import java.time.Duration;
 
public class WaitUtils {
 
    private final WebDriver driver;
    private final WebDriverWait wait;
 
    public WaitUtils(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }
 
    public void waitForVisible(WebElement element) {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
        } catch (TimeoutException e) {
            throw new RuntimeException("Element not visible: " + getLocatorInfo(element));
        }
    }
 
    public void waitForClickable(WebElement element) {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(element));
        } catch (TimeoutException e) {
            throw new RuntimeException("Element not clickable: " + getLocatorInfo(element));
        }
    }
 
    public WebElement waitUntilVisible(By locator) {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        } catch (TimeoutException e) {
            throw new RuntimeException("Locator not visible: " + locator.toString());
        }
    }
 
    public WebElement waitUntilClickable(By locator) {
        try {
            return wait.until(ExpectedConditions.elementToBeClickable(locator));
        } catch (TimeoutException e) {
            throw new RuntimeException("Locator not clickable: " + locator.toString());
        }
    }
 
    public void waitForInvisibility(WebElement element) {
        try {
            wait.until(ExpectedConditions.invisibilityOf(element));
        } catch (TimeoutException e) {
            throw new RuntimeException("Element did not become invisible: " + getLocatorInfo(element));
        }
    }
 
    public void waitForTitle(String expectedTitle) {
        try {
            wait.until(ExpectedConditions.titleIs(expectedTitle));
        } catch (TimeoutException e) {
            throw new RuntimeException("Title did not match: " + expectedTitle);
        }
    }
    public WebDriverWait getWait(int timeoutSeconds) {
        return new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
    }

    // Optional: helper to extract element info for better error messages
    private String getLocatorInfo(WebElement element) {
        try {
            String desc = element.toString();
            return desc.contains("->") ? desc.split("->")[1].trim() : desc;
        } catch (Exception e) {
            return "unknown element";
        }
    }
}
 