package com.parameters;

import java.io.IOException;
import java.util.Properties;

public class ConfigReader {

    private static Properties properties;

    static {
        try {
            properties = new Properties();
            properties.load(ConfigReader.class.getClassLoader()
                    .getResourceAsStream("config.properties"));
        } catch (IOException | NullPointerException e) {
            throw new RuntimeException("config.properties file NOT FOUND in classpath!", e);
        }
    }

    // Generic getter
    public static String get(String key) {
        String value = properties.getProperty(key);
        return (value != null) ? value.trim() : null;
    }

    // Convenience getters
    public static String getBrowser() { return get("browser"); }
    public static String getBaseUrl() { return get("baseUrl"); }

    // User details
    public static String getUserName() { return get("username"); }
    public static String getUserEmail() { return get("userEmail"); }
    public static String getUserMobile() { return get("userMobile"); }

    // Location, brand, occupancy, gender
    public static String getLocation1() { return get("location1"); }
    public static String getBrand1() { return get("brand1"); }
    public static String getOccupancy1() { return get("occ1"); }
    public static String getGender1() { return get("gender1"); }

    // Budget
    public static String getMinBudget1() { return get("min1"); }
    public static String getMaxBudget1() { return get("max1"); }

    // Amenities
    public static String getAmenity1() { return get("amen1"); }
    public static String getAmenity2() { return get("amen2"); }

    // ✅ Additions for your test framework
    public static String getPgListingUrl() { return get("pgListingUrl"); }
    public static String getExcelPath() { return get("excelPath"); }
}
