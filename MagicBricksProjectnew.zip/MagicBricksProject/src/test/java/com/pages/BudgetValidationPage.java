package com.pages;

import com.setup.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BudgetValidationPage extends BasePage {

    @FindBy(id = "rangeMinLinkbudgetinput")
    private WebElement minBudgetInput;

    @FindBy(id = "rangeMaxLinkbudgetinput")
    private WebElement maxBudgetInput;

    @FindBy(xpath = "//*[@id='budget']/div[2]/a")
    private WebElement budgetDoneBtn;

    @FindBy(css = ".budgetError")
    private WebElement budgetError;

    public void applyInvalidBudget(String min, String max) {
        type(minBudgetInput, min);
        type(maxBudgetInput, max);
        click(budgetDoneBtn);
    }

    public boolean isErrorMessageDisplayed() {
        return budgetError.isDisplayed();
    }
}
