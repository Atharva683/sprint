package com.pages;

import com.setup.BasePage;
import com.setup.DriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Map;

public class PGListingPage extends BasePage {

	private final WebDriver driver;
	private static final int TIMEOUT = 15;

	public PGListingPage() {
		this.driver = DriverManager.getDriver();
	}

	// ===== Helpers =====
	private WebElement visible(By locator) {
		return new WebDriverWait(driver, Duration.ofSeconds(TIMEOUT))
				.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	//    private WebElement clickable(By locator) {
	//        return new WebDriverWait(driver, Duration.ofSeconds(TIMEOUT))
	//                .until(ExpectedConditions.elementToBeClickable(locator));
	//    }

	private void safeClick(WebElement el) {
		try {
			el.click();
		} catch (Exception e) {
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", el);
		}
	}

	private void clickWithRetry(By locator) {
		int attempts = 0;
		while (attempts < 2) {
			try {
				WebElement el = new WebDriverWait(driver, Duration.ofSeconds(TIMEOUT))
						.until(ExpectedConditions.elementToBeClickable(locator));
				el.click();
				return;
			} catch (StaleElementReferenceException se) {
				attempts++;
				System.out.println("Retrying click due to stale element: " + locator);
			}
		}
		throw new RuntimeException("Failed to click after retries: " + locator);
	}

	private void waitInvisible(By locator) {
		new WebDriverWait(driver, Duration.ofSeconds(TIMEOUT))
		.until(ExpectedConditions.invisibilityOfElementLocated(locator));
	}

	private String norm(String s) {
		return s == null ? "" : s.trim().toLowerCase();
	}

	private void sleep(long ms) {
		try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
	}

	// ===== Locators =====
	private final By locationField   = By.id("refine_keyword");

	private final By genderHeader    = By.xpath("//*[@id='gender-id']/div[1]");
	private final By genderPanel     = By.id("refinegender");

	private final By occupancyHeader = By.xpath("//*[@id='occupancy-id']/div[1]");
	private final By occupancyPanel  = By.id("refineoccupancy");

	private final By brandHeader     = By.xpath("//*[@id='pgubirfnum-id']/div[1]");
	private final By brandPanel      = By.id("refinepgubirfnum");

	@FindBy(xpath="/html/body/div[4]/div/div[1]/div/div/div/div/div/div[7]/div[1]/div")
	private WebElement budgetHeader;


	@FindBy(xpath="/html/body/div[4]/div/div[1]/div/div/div/div/div/div[7]/div[2]/div/div/div/div[2]")
	private WebElement done;
	
	@FindBy(id="rangeMinLinkbudgetinput")
	private WebElement budgetMinInput;

	@FindBy(id="rangeMaxLinkbudgetinput")
	private WebElement budgetMaxInput;

	//	private final By budgetHeader    = By.xpath("//*[@id='inputbudget']");
	//	private final By budgetMinInput  = By.id("rangeMinLinkbudgetinput");
	//	private final By budgetMaxInput  = By.id("rangeMaxLinkbudgetinput");

	// ✅ Correct locator for PG listing cards
	private final By pgListingCards  = By.cssSelector("div.m-srp-card");

	// ===== Apply filters =====
	public void applyLocation(String location) {
		if (location == null || location.isBlank()) return;
		try {
			WebElement crossIcon = new WebDriverWait(driver, Duration.ofSeconds(5))
					.until(ExpectedConditions.elementToBeClickable(
							By.xpath("//*[@id='autoSuggestInputDivrefine_keyword']/div[1]/div[2]")));
			crossIcon.click();
			System.out.println("Cleared location field using cross icon");
		} catch (TimeoutException e) {
			System.out.println("Cross icon not visible, field may already be empty");
		}

		WebElement locInput = visible(locationField);
		locInput.clear();
		locInput.sendKeys(location);
		System.out.println("Entered location: " + location);

		try {
			WebElement overlay = new WebDriverWait(driver, Duration.ofSeconds(5))
					.until(ExpectedConditions.elementToBeClickable(
							By.cssSelector("div.filter-overlay-autosuggest")));
			overlay.click();
			System.out.println("Clicked overlay once to close autosuggest");
		} catch (TimeoutException e) {
			System.out.println("Overlay not found or not visible");
		}

		sleep(1000);
	}

	public void applyGender(String gender) {
		if (gender == null || gender.isBlank()) return;
		clickWithRetry(genderHeader);

		String g = norm(gender);
		By optionLocator;
		switch (g) {
		case "boys": optionLocator = By.xpath("//*[@id='refinegender']//label[@for='gender_Male']"); break;
		case "girls": optionLocator = By.xpath("//*[@id='refinegender']//label[@for='gender_Female']"); break;
		case "both": optionLocator = By.xpath("//*[@id='refinegender']//label[@for='gender_Both']"); break;
		default: throw new RuntimeException("Unknown gender option: " + gender);
		}

		clickWithRetry(optionLocator);
		waitInvisible(genderPanel);
		System.out.println("Gender applied: " + gender);
	}

	public void applyOccupancy(String occupancy) {
		if (occupancy == null || occupancy.isBlank()) return;
		clickWithRetry(occupancyHeader);

		String o = norm(occupancy);
		By optionLocator;
		switch (o) {
		case "single": optionLocator = By.xpath("//*[@id='refineoccupancy']//label[@for='occupancy_16011']"); break;
		case "double": optionLocator = By.xpath("//*[@id='refineoccupancy']//label[@for='occupancy_16014']"); break;
		case "triple": optionLocator = By.xpath("//*[@id='refineoccupancy']//label[@for='occupancy_16015']"); break;
		case "others": optionLocator = By.xpath("//*[@id='refineoccupancy']//label[@for='occupancy_16018-16017-16016']"); break;
		default: throw new RuntimeException("Unknown occupancy option: " + occupancy);
		}

		clickWithRetry(optionLocator);
		waitInvisible(occupancyPanel);
		System.out.println("Occupancy applied: " + occupancy);
	}

	public void applyBrand(String brand) {
		if (brand == null || brand.isBlank()) return;
		clickWithRetry(brandHeader);

		By optionLocator = By.xpath("//*[@id='refinepgubirfnum']//label[normalize-space(text())='" + brand.trim() + "']");
		clickWithRetry(optionLocator);

		waitInvisible(brandPanel);
		System.out.println("Brand applied: " + brand);
	}



	//------------------------------------------------------------------------------------------
	public void applyBudget(String minValue, String maxValue) {
		//	    if ((minValue == null || minValue.isBlank()) && (maxValue == null || maxValue.isBlank())) return;

		//	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

		// Step 1: Click budget header
		//	    WebElement header = wait.until(ExpectedConditions.elementToBeClickable(budgetHeader));
		click(budgetHeader);
		type(budgetMinInput,minValue);
		click(done);
		click(budgetHeader);
		type(budgetMaxInput,maxValue);
		click(done);
		// Step 2: Enter Min
		//	    WebElement minField = wait.until(ExpectedConditions.visibilityOfElementLocated(budgetMinInput));
		//	    minField.clear();
		//	    if (minValue != null && !minValue.isBlank()) {
		//	        minField.sendKeys(minValue);
		//	    }
		//	    System.out.println("Budget Min applied: " + minValue);
		//
		//	    // Step 3: Click Max field if present
		//	    List<WebElement> maxFields = driver.findElements(budgetMaxInput);
		//	    if (!maxFields.isEmpty()) {
		//	        safeClick(maxFields.get(0));
		//	    }
		//
		//	    // Step 4: Click budget header again
		//	    header = wait.until(ExpectedConditions.elementToBeClickable(budgetHeader));
		//	    safeClick(header);
		//
		//	    // Step 5: Enter Max only if field is visible
		//	    maxFields = driver.findElements(budgetMaxInput);
		//	    if (!maxFields.isEmpty()) {
		//	        WebElement maxField = maxFields.get(0);
		//	        maxField.clear();
		//	        if (maxValue != null && !maxValue.isBlank()) {
		//	            maxField.sendKeys(maxValue);
		//	        }
		//	        System.out.println("Budget Max applied: " + maxValue);
		//	    } else {
		//	        System.out.println("⚠️ Max field not visible — likely cleared by validation.");
		//	    }

		// Step 6: Final click on budget header
		//	    header = wait.until(ExpectedConditions.elementToBeClickable(budgetHeader));
		//	    safeClick(header);

		// 👉 No validation here — scenario just completes
	}


	//--------------------------------------------------------------------------------------------------------------

	public void applyFilters(Map<String, String> data) {
		if (data == null) return;
		applyLocation(data.get("Location"));
		applyGender(data.get("Gender"));
		applyOccupancy(data.get("Occupancy"));
		applyBrand(data.get("Brand"));
		applyBudget(data.get("MinBudget"), data.get("MaxBudget"));
	}

	public void applyFiltersFromExcel(String location, String gender, String occupancy, String brand, String minBudget, String maxBudget) {
		applyLocation(location);
		applyGender(gender);
		applyOccupancy(occupancy);
		applyBrand(brand);
		applyBudget(minBudget, maxBudget);
	}

	// ===== Listing count =====
	public int getListingCount() {
		return driver.findElements(pgListingCards).size();
	}


	// ===== Validation =====
	public boolean validateListingsUpdated() {
		int count = getListingCount();
		System.out.println("Listings after filters: " + count);
		return count > 0;
	}

	public boolean verifyListingsMatchFilters(String location, String gender, String occupancy,
			String brand, String minBudget, String maxBudget) {
		int min = (minBudget != null && !minBudget.isBlank()) ? Integer.parseInt(minBudget) : 0;
		int max = (maxBudget != null && !maxBudget.isBlank()) ? Integer.parseInt(maxBudget) : Integer.MAX_VALUE;

		List<WebElement> listings = driver.findElements(pgListingCards);
		if (listings.isEmpty()) {
			System.out.println("No listings found to validate.");
			return false;
		}

		for (int i = 0; i < listings.size(); i++) {
			String text = "";
			try {

				// ✅ Re-fetch each card to avoid stale references
				WebElement card = driver.findElements(pgListingCards).get(i);
				text = card.getText().toLowerCase();
			} catch (StaleElementReferenceException se) {
				System.out.println("Stale element at index " + i + ", retrying...");
				WebElement card = driver.findElements(pgListingCards).get(i);
				text = card.getText().toLowerCase();
			}

			// Location check
			if (location != null && !location.isBlank() && !text.contains(location.toLowerCase())) {
				System.out.println("Location mismatch in card: " + text);
				return false;
			}

			// Normalized gender check
			if (gender != null && !gender.isBlank()) {
				String g = gender.toLowerCase();
				boolean match = false;
				if (g.equals("girls")) {
					match = text.contains("girls") || text.contains("female") || text.contains("women")
							|| text.contains("unisex") || text.contains("coed");
				} else if (g.equals("boys")) {
					match = text.contains("boys") || text.contains("male") || text.contains("men")
							|| text.contains("unisex") || text.contains("coed");
				} else if (g.equals("both")) {
					match = text.contains("unisex") || text.contains("coed") || text.contains("both");
				}
				if (!match) {
					System.out.println("Gender mismatch in card: " + text);
					return false;
				}
			}

			// Occupancy check
			if (occupancy != null && !occupancy.isBlank() && !text.contains(occupancy.toLowerCase())) {
				System.out.println("Occupancy mismatch in card: " + text);
				return false;
			}

			// Brand check (relaxed)
			if (brand != null && !brand.isBlank() && !text.contains(brand.toLowerCase())) {
				System.out.println("⚠️ Brand not found in card: " + text);
				// Don't fail — just log
			}

			// Budget validation
			try {
				String rentStr = text.replaceAll("[^0-9]", "");
				if (!rentStr.isEmpty()) {
					int rent = Integer.parseInt(rentStr);
					if (rent < min || rent > max) {
						System.out.println("Budget mismatch in card: " + rent);
						return false;
					}
				}
			} catch (Exception ignored) {}
		}

		System.out.println("All listings match the applied filters.");
		return true;
	}

	// Count PG cards currently displayed
	public int getPgCardCount() {
		List<WebElement> cards = driver.findElements(By.cssSelector(".pg-card"));
		return cards.size();
	}


	//    // Check if fields were reset/cleared (uses your existing locators)
	//    public boolean areBudgetFieldsReset() {
	//        WebElement min = visible(budgetMinInput);
	//        WebElement max = visible(budgetMaxInput);
	//        String minVal = min.getAttribute("value");
	//        String maxVal = max.getAttribute("value");
	//        return (minVal == null || minVal.isEmpty()) || (maxVal == null || maxVal.isEmpty());
	//    }

	//    // Wait briefly for UI reaction (error or reset)
	//    public void waitForBudgetValidation() {
	//        new WebDriverWait(driver, Duration.ofSeconds(5)).until(
	//            ExpectedConditions.or(
	//                ExpectedConditions.presenceOfElementLocated(By.cssSelector(".budget-error-msg, .error-msg, .budget__error")),
	//                ExpectedConditions.attributeToBe(visible(budgetMinInput), "value", "")
	//            )
	//        );
	//    }
	//	public boolean isMaxFieldEmpty() {
	//		WebElement maxField = new WebDriverWait(driver, Duration.ofSeconds(5))
	//				.until(ExpectedConditions.visibilityOfElementLocated(budgetMaxInput));
	//		return maxField.getAttribute("value").isEmpty();
	//	}
	//
	//	public boolean isMinFieldRetained() {
	//		WebElement minField = new WebDriverWait(driver, Duration.ofSeconds(5))
	//				.until(ExpectedConditions.visibilityOfElementLocated(budgetMinInput));
	//		return !minField.getAttribute("value").isEmpty();
	//	}
	//
	//	public boolean isBudgetHeaderShowingOnlyMin(String expectedMin) {
	//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
	//		WebElement headerText = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("inputbudget")));
	//		String text = headerText.getText();
	//		System.out.println("Budget header text: " + text);
	//		return text.contains("Min " + expectedMin) && !text.toLowerCase().contains("max");
	//	}

	public String getBudgetResultMessage() {
	    try {
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
	        WebElement headerText = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(By.id("inputbudget"))
	        );

	        String text = headerText.getText().trim();
	        System.out.println("Budget header text: " + text);

	        // Build a dynamic message based on UI state
	        if (text.toLowerCase().contains("min") && !text.toLowerCase().contains("max")) {
	            return "Invalid range applied → " + text;
	        } else if (text.toLowerCase().contains("min") && text.toLowerCase().contains("max")) {
	            return "Valid range applied → " + text;
	        } else {
	            return "No budget applied → " + text;
	        }
	    } catch (Exception e) {
	        return "Error fetching budget header: " + e.getMessage();
	    }
	}



}