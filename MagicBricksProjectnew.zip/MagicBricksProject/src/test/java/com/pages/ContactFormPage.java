package com.pages;

import com.setup.BasePage;
import com.parameters.ConfigReader;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ContactFormPage extends BasePage {

    private final WebDriver driver;

    public ContactFormPage(WebDriver driver) {
        this.driver = driver;
    }

    // ===== Locators for form fields =====
    @FindBy(id = "username")
    private WebElement nameField;

    @FindBy(id = "userEmail")
    private WebElement emailField;

    @FindBy(id = "userMobile")
    private WebElement mobileField;

    @FindBy(xpath = "//*[@id='contactAdvertiser']//label[contains(text(),'Triple Sharing')]")
    private WebElement tripleSharingOption;

    @FindBy(id = "showProjContactButtonText")
    private WebElement contactButton;

    // ===== Locators for SMS and popup =====
    @FindBy(id = "smsNo")
    private WebElement smsNoField;

    @FindBy(xpath = "//div[@class='thank-you__pg__success--msg']")
    private WebElement thankYouPopupMsg;

    // ===== Actions =====
    public void fillContactForm() {
        type(nameField, ConfigReader.getUserName());
        type(emailField, ConfigReader.getUserEmail());
        type(mobileField, ConfigReader.getUserMobile());

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", tripleSharingOption);
        click(tripleSharingOption);

        click(contactButton);
    }

    public void waitForSmsFieldAndPopupAfterManualVerify() {
        // Wait for SMS field to appear and focus it
        new WebDriverWait(driver, Duration.ofSeconds(6))
            .until(ExpectedConditions.visibilityOf(smsNoField));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", smsNoField);
        try {
            smsNoField.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", smsNoField);
        }

        System.out.println("➡️ Please enter the 3-digit OTP manually and click Verify...");

        // Wait for Thank You popup message after manual Verify
        WebElement popupMsg = new WebDriverWait(driver, Duration.ofSeconds(12))
            .until(ExpectedConditions.visibilityOf(thankYouPopupMsg));

        // Assertion: check popup text
        String actualText = popupMsg.getText().trim();
        String expectedText = "Contact details of Owner sent to you by SMS/Email.";

        if (actualText.equals(expectedText)) {
            System.out.println("✅ Thank You popup appeared with correct message — test case PASSED.");
        } else {
            throw new AssertionError("❌ Popup text mismatch. Found: " + actualText);
        }
    }
}
