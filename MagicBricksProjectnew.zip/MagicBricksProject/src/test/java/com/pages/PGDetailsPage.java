package com.pages;

import com.setup.BasePage;
import com.setup.DriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class PGDetailsPage extends BasePage {

    private final WebDriver driver;

    public PGDetailsPage() {
        this.driver = DriverManager.getDriver();
    }

    // ===== Locators =====
    @FindBy(xpath = "(//span[@class='m-srp-card__title__name'])[1]")
    private WebElement firstPgCard;

    @FindBy(css = "h1")
    private WebElement pgName;

    @FindBy(xpath = "//*[@id='section_propDetails']//li[1]/div[2]")
    private WebElement rentValue;

    @FindBy(css = ".pg-prop-details__info__uspdetails")
    private WebElement locationInfo;

    @FindBy(xpath = "//a[contains(text(),'Contact Owner')]")
    private WebElement contactOwnerBtn;

    @FindBy(xpath = "//a[contains(text(),'View Phone No')]")
    private WebElement viewPhoneBtn;

    // Popup message div
    private By popupMessageLocator = By.cssSelector(".thank-you__pg__success--msg");

    // ===== Navigation =====
    public void openFirstPgListing() {
        scrollAndClick(firstPgCard);

        String originalWindow = driver.getWindowHandle();
        new WebDriverWait(driver, Duration.ofSeconds(10))
            .until(ExpectedConditions.numberOfWindowsToBe(2));

        for (String handle : driver.getWindowHandles()) {
            if (!handle.equals(originalWindow)) {
                driver.switchTo().window(handle);
                break;
            }
        }

        new WebDriverWait(driver, Duration.ofSeconds(15))
            .until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector(".pg-prop-details__info")));
    }

    // ===== Helper: wait + scroll + get text =====
    private String waitScrollGetText(WebElement element) {
        new WebDriverWait(driver, Duration.ofSeconds(10))
            .until(ExpectedConditions.visibilityOf(element));
        ((JavascriptExecutor) driver)
            .executeScript("arguments[0].scrollIntoView({block:'center'});", element);
        return element.getText().trim();
    }

    // ===== Validations =====
    public boolean isLoaded() {
        try {
            new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.visibilityOf(pgName));
            return true;
        } catch (TimeoutException e) {
            return false;
        }
    }

    public String getPgName() { return waitScrollGetText(pgName); }
    public String getRentValue() { return waitScrollGetText(rentValue); }
    public String getLocationInfo() { return waitScrollGetText(locationInfo); }

    public String getPopupMessage() {
        try {
            WebElement popup = new WebDriverWait(driver, Duration.ofSeconds(15))
                .until(ExpectedConditions.visibilityOfElementLocated(popupMessageLocator));
            return popup.getText().trim();
        } catch (TimeoutException e) {
            return "Popup not displayed";
        }
    }

    public boolean isDirectContactVisible() {
        return driver.findElements(By.cssSelector(".contact-number")).size() > 0;
    }

    // ===== Actions with auto-scroll =====
    private void scrollAndClick(WebElement element) {
        new WebDriverWait(driver, Duration.ofSeconds(10))
            .until(ExpectedConditions.elementToBeClickable(element));
        ((JavascriptExecutor) driver)
            .executeScript("arguments[0].scrollIntoView({block:'center'});", element);
        try {
            element.click();
        } catch (Exception e) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
    }

    public void clickContactOwner() {
        scrollAndClick(contactOwnerBtn);

        // After clicking, the contact form appears — fill it
        ContactFormPage formPage = new ContactFormPage(driver);
        formPage.fillContactForm();
    }

    public void clickViewPhoneNumber() {
        scrollAndClick(viewPhoneBtn);
    }
}
