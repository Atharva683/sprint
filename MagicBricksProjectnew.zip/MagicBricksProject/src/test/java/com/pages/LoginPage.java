package com.pages;

import com.setup.BasePage;
import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage extends BasePage {

    // Menu icon (hamburger) used in mobile/responsive layout
    @FindBy(css = "a.mb-header__main__link.js-menu-link")
    private WebElement menuIcon;

    // "My Activity" link inside dropdown
    @FindBy(xpath = "//span[text()='My Activity']")
    private WebElement myActivityLink;

    // Login/Signup CTA inside the dropdown
    @FindBy(css = "a.mb-login__drop-cta")
    private WebElement loginSignupLink;

    // Phone/email input field in login window
    @FindBy(id = "emailOrMobile")
    private WebElement phoneField;

    // Next button after captcha
    @FindBy(id = "btnStep1")
    private WebElement nextButton;

    // Continue button after OTP
    @FindBy(xpath = "//*[@id='verifyOtpDiv']/div[2]/div[3]/button")
    private WebElement continueButton;

    public void performLogin(String phoneNumber) {
        driver.manage().deleteAllCookies();

        // Step 1: Go directly to PG listings page
        driver.get("https://www.magicbricks.com/pg-in-mumbai-pppfr");

        // Step 2: Click menu icon to reveal dropdown
        //click(menuIcon);

        // Step 3: Click "My Activity"
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", myActivityLink);
        click(myActivityLink);

        // Step 4: Click Login/Signup CTA
        click(loginSignupLink);

        // Step 5: Switch to new login window
        String originalWindow = driver.getWindowHandle();
        waitForWindowCountToBe(2);
        switchToNewWindow(originalWindow);

        // Step 6: Enter phone/email
        type(phoneField, phoneNumber);

        // Step 7: Wait for manual captcha entry
        System.out.println("⏳ Please solve captcha manually...");
        click(nextButton);

        // Step 8: Wait for manual OTP entry
        System.out.println("⏳ Please enter OTP manually...");
        click(continueButton);

        // Step 9: Navigate back to PG listings page after login
        driver.get("https://www.magicbricks.com/pg-in-mumbai-pppfr");
    }

    private void waitForWindowCountToBe(int count) {
        new WebDriverWait(driver, Duration.ofSeconds(10))
            .until(driver -> driver.getWindowHandles().size() == count);
    }

    private void switchToNewWindow(String originalWindow) {
        for (String handle : driver.getWindowHandles()) {
            if (!handle.equals(originalWindow)) {
                driver.switchTo().window(handle);
                break;
            }
        }
    }
}
