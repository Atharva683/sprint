package com.pages;

import com.parameters.ConfigReader;
import com.parameters.ExcelUtils;
import com.parameters.WaitUtils;
import com.setup.BasePage;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RentSearchPage extends BasePage {

    private final WebDriver driver;
    private final WaitUtils wait;

    // Keep track of last entered city for reporting/validation
    private String citylocation;

    public RentSearchPage(WebDriver driver) {
        super(); // calls BasePage(WebDriver)
        this.driver = driver;
        this.wait = new WaitUtils(driver);
        PageFactory.initElements(driver, this);
    }

    // ===========================
    // Rent Tab
    // ===========================
    @FindBy(id = "tabRENT")
    private WebElement rentTab;


    public void hoverAndClickRentTab() {
        try {
            wait.waitForVisible(rentTab);
            wait.waitForClickable(rentTab);

            // No need to hover if it's a div — just click
            rentTab.click();

            System.out.println("✅ Rent tab clicked successfully");
        } catch (Exception e) {
            throw new RuntimeException("❌ Failed to click Rent tab: " + e.getMessage());
        }
    }


    // ===========================
    // Location Selection
    // ===========================
    @FindBy(id = "keyword_autoSuggestSelectedDiv")
    private WebElement locationWrapper;

    @FindBy(css = ".mb-search__tag-close")
    private WebElement clearLocation;

    @FindBy(id = "keyword")
    private WebElement locationInput;

    @FindBy(xpath = "(//div[@class='mb-search__auto-suggest__item'])[1]")
    private WebElement optionSelection;

    public void enterLocation(String location) throws InterruptedException {
        if (location.trim().isEmpty()) {
            click(locationWrapper);
            click(clearLocation);
            return;
        }

        citylocation = location;
        click(locationWrapper);

        try {
            click(clearLocation);
        } catch (Exception ignored) {
            System.out.println("No existing location to clear.");
        }

        type(locationInput, location);

        Thread.sleep(500); // allow dropdown to render
        wait.waitForClickable(optionSelection);
        click(optionSelection);

        // ✅ Post-selection validation: confirm location tag appears
        By locationTag = By.xpath("//div[contains(@class,'mb-search__tag') and contains(text(),'" + location + "')]");
        wait.waitUntilVisible(locationTag);

        System.out.println("Entered location: " + citylocation);
    }

    // ===========================
    // Property Selection
    // ===========================
    @FindBy(xpath = "//*[@class='mb-search__property']")
    private WebElement propertyTypeDropdown;

    @FindBy(id = "10002_10003_10021_10022")
    private WebElement flat;

    @FindBy(id = "10001_10017")
    private WebElement houseOrVilla;

    @FindBy(id = "10000")
    private WebElement plot;

    @FindBy(id = "11700")
    private WebElement oneBHK;

    @FindBy(id = "11701")
    private WebElement twoBHK;

    @FindBy(id = "11702")
    private WebElement threeBHK;

    public void selectPropertyType(String propertyType) {
        click(propertyTypeDropdown);

        switch (propertyType.toLowerCase()) {
            case "villa":
                wait.waitForClickable(houseOrVilla);
                click(houseOrVilla);
                break;
            case "flat":
                wait.waitForClickable(flat);
                click(flat);
                break;
            case "plot":
                wait.waitForClickable(plot);
                click(plot);
                break;
            case "1bhk":
                wait.waitForClickable(oneBHK);
                click(oneBHK);
                break;
            case "2bhk":
                wait.waitForClickable(twoBHK);
                click(twoBHK);
                break;
            case "3bhk":
                wait.waitForClickable(threeBHK);
                click(threeBHK);
                break;
            default:
                System.out.println("Unsupported property type: " + propertyType);
        }

        System.out.println("Selected property type: " + propertyType);
    }

 // In RentSearchPage
    public void selectPropertyTypesFromConfig(String propertyTypes) {
        String[] types = propertyTypes.split(",");
        for (String type : types) {
            selectPropertyType(type.trim());
        }
    }


    // ===========================
    // Budget Selection
    // ===========================
    @FindBy(css = "div.mb-search__title span#rent_budget_lbl")
    private WebElement budget_dropdown;

    @FindBy(css = "input#budgetMin")
    private WebElement budgetMin;

    @FindBy(css = "input#budgetMax")
    private WebElement budgetMax;

    public void enterBudgetRange(String min, String max) {
        click(budget_dropdown);
        type(budgetMin, min);
        type(budgetMax, max);

        System.out.println("Budget range entered: " + min + " - " + max);
    }

    // ===========================
    // Search Button
    // ===========================
    @FindBy(xpath = "//div[@class='mb-search__btn' and contains(.,'Search')]")
    private WebElement searchButton;

    public void clickSearch() throws InterruptedException {
        click(searchButton);
        Thread.sleep(3000); // allow results page to load

        // ✅ Post-click validation: wait until results container appears
        By resultsContainer = By.xpath("//div[contains(@class,'mb-srp__list')]");
        wait.waitUntilVisible(resultsContainer);

        System.out.println("Clicked Search button and results loaded");
    }

    // ===========================
    // Open First Property
    // ===========================
    public void openFirstProperty() {
        String currentWindow = driver.getWindowHandle();

        By firstPropertyLocator = By.xpath("(//div[contains(@class,'mb-srp__card')])[1]");
        WebElement firstPropertyElement = wait.waitUntilClickable(firstPropertyLocator);

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", firstPropertyElement);
        firstPropertyElement.click();
        System.out.println("Clicked first property card");

        // Switch to new window
        wait.getWait(10).until(d -> d.getWindowHandles().size() > 1);
        for (String handle : driver.getWindowHandles()) {
            if (!handle.equals(currentWindow)) {
                driver.switchTo().window(handle);
                break;
            }
        }
        System.out.println("Switched to new property window");
    }
    
    @FindBy(xpath = "//*[@id='more-details']/div[2]/div[1]/a")
    private WebElement viewAllDetailsLink;
    public void viewAllDetails() {
        try {
            wait.waitForClickable(viewAllDetailsLink);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", viewAllDetailsLink);
            viewAllDetailsLink.click();
            System.out.println("Clicked on 'View All Details'");

            // ✅ Post-click validation: wait until details section is visible
            By detailsSection = By.xpath("/html/body/div/div/div/div[4]/div[2]/div/div/div[1]/section[2]/div[2]/div[1]/a");
            wait.waitUntilVisible(detailsSection);
            System.out.println("Property details section is visible");
        } catch (Exception e) {
            throw new RuntimeException("Failed to click 'View All Details': " + e.getMessage());
        }
    }

 // ===========================
 // Property Detail Locators
 // ===========================

 // Rental Value
 @FindBy(xpath = "//div[normalize-space(text())='Rental Value']/following-sibling::div")
 private WebElement rentalValue;

 // Security Deposit
 @FindBy(xpath = "//div[normalize-space(text())='Security Deposit']/following-sibling::div")
 private WebElement securityDeposit;

 // Address
 @FindBy(css = "div.mb-ldp__loc")
 private WebElement address;

 // Landmarks
 @FindBy(xpath = "//div[normalize-space(text())='Landmarks']/following-sibling::div")
 private WebElement landmarks;

 // Furnishing
 @FindBy(xpath = "//div[normalize-space(text())='Furnishing']/following-sibling::div")
 private WebElement furnishing;

 // Flooring
 @FindBy(xpath = "//div[normalize-space(text())='Flooring']/following-sibling::div")
 private WebElement flooring;

 // Overlooking
 @FindBy(xpath = "//div[normalize-space(text())='Overlooking']/following-sibling::div")
 private WebElement overlooking;

 // Age of Construction
 @FindBy(xpath = "//div[normalize-space(text())='Age of Construction']/following-sibling::div")
 private WebElement ageOfConstruction;

 // Additional Rooms
 @FindBy(xpath = "//div[normalize-space(text())='Additional Rooms']/following-sibling::div")
 private WebElement additionalRooms;

 // Water Availability
 @FindBy(xpath = "//div[normalize-space(text())='Water Availability']/following-sibling::div")
 private WebElement waterAvailability;

 // Electricity Status
 @FindBy(xpath = "//div[normalize-space(text())='Status of Electricity']/following-sibling::div")
 private WebElement electricityStatus;

 // Floors Allowed
 @FindBy(xpath = "//div[normalize-space(text())='No. of Floors Allowed']/following-sibling::div")
 private WebElement floorsAllowed;

 // Lift
 @FindBy(xpath = "//div[normalize-space(text())='Lift']/following-sibling::div")
 private WebElement lift;

 // Description
 @FindBy(css = "div.mb-ldp__description")
 private WebElement description;
 
//Class-level field to hold extracted details
private Map<String, String> propertyDetails = new HashMap<>();

//=============================
//Method 1: Extract details
//=============================
public void extractPropertyDetails() {
    propertyDetails.clear(); // reset map

    List<WebElement> items = driver.findElements(By.cssSelector("li.mb-ldp_more-dtl_list--item"));
    for (WebElement item : items) {
        try {
            WebElement label = item.findElement(By.cssSelector("div.mb_ldp_more-dtl_list-label"));
            WebElement value = item.findElement(By.cssSelector("div.mb_ldp_more-dtl_list-value"));

            String key = label.getText().trim();
            String val = value.getText().trim();

            propertyDetails.put(key, val);
            System.out.println(key + ": " + val);
        } catch (Exception ignored) {
            // Skip if label or value is missing
        }
    }

    // Add static fields from config
    propertyDetails.put("Location", citylocation);
    propertyDetails.put("PropertyType", "Rent");
    propertyDetails.put("MinBudget", ConfigReader.get("budgetMin"));
    propertyDetails.put("MaxBudget", ConfigReader.get("budgetMax"));
    propertyDetails.put("Result", "PASS");
}


//=============================
//Method 2: Write details to Excel
//=============================
public void writeDetailsToExcel() throws IOException {
    // Use relative path as requested
    ExcelUtils excel = new ExcelUtils("src/test/resources/Exceldata/Rent_data.xlsx", "Rent_data");

    int rowNum = excel.getRowCount(); // appends to next available row

    for (Map.Entry<String, String> entry : propertyDetails.entrySet()) {
        excel.setCellDataByColumnName(entry.getValue(), rowNum, entry.getKey());
    }

    excel.saveChanges();
    excel.closeWorkbook();

    System.out.println("✅ Property details written to ExcelData/Rent_data.xlsx at row: " + rowNum);
}



}
