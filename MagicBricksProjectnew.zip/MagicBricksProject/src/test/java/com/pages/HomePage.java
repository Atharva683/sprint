package com.pages;

import com.setup.BasePage;
import com.setup.DriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {

    @FindBy(id = "rentheading")
    private WebElement rentMenu;

    private Actions actions = new Actions(DriverManager.getDriver());

    // Hover over the Rent dropdown
    public void hoverRentMenu() {
        wait.waitForVisible(rentMenu);
        actions.moveToElement(rentMenu).perform();
    }

    // Click PG option and switch to new tab
    public void selectPgOption(String optionText) {
        actions.moveToElement(rentMenu).perform();

        WebElement link = DriverManager.getDriver()
                .findElement(By.xpath("//a[contains(text(),'" + optionText + "')]"));

        ((JavascriptExecutor) DriverManager.getDriver()).executeScript("arguments[0].click();", link);

        // Switch to the new window
        String originalWindow = DriverManager.getDriver().getWindowHandle();
        for (String windowHandle : DriverManager.getDriver().getWindowHandles()) {
            if (!windowHandle.equals(originalWindow)) {
                DriverManager.getDriver().switchTo().window(windowHandle);
                break;
            }
        }
    }
}
