package com.setup;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class DriverManager {
	private static WebDriver driver;


	private DriverManager() {}


	public static WebDriver getDriver() {
		 if (driver == null) {
//			 	System.setProperty("webdriver.chrome.driver", "C:\\driver\\chromedriver.exe");
		        ChromeOptions options = new ChromeOptions();
//
//		        // ✅ Block notifications
//		        options.addArguments("--disable-notifications");
//
//		        // ✅ Optional: block geolocation prompts
//		        options.addArguments("--disable-geolocation");
//
		        driver = new ChromeDriver(options);
//		        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		        driver.manage().window().maximize();
		    }
		    return driver;

	}


	public static void quitDriver() {
	    if (driver != null) {
	        try {
	            // Wait for 3 seconds before quitting
	            Thread.sleep(3000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        driver.quit();
	        driver = null;
	    }
	}

}