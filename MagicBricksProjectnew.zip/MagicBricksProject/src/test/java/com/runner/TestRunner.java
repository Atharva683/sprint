package com.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(
		features = "src/test/resources/Features",
		glue = {"com.stepDefinitionTestNG"},
				plugin = {
						"pretty",
						"html:target/cucumber-report.html",
						"json:target/cucumber.json",
						"junit:target/cucumber.xml",
						"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
				},
		monochrome = true,
		tags = "@MagicBricks"
		
		)
public class TestRunner extends AbstractTestNGCucumberTests {
	
	
}