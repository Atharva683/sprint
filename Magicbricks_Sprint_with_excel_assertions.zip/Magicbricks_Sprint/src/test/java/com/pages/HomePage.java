package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.setup.DriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class HomePage {
    private WebDriver driver;
    private WebDriverWait wait;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        PageFactory.initElements(driver, this);
    }

    // Example locators - update to match the actual site under test
    @FindBy(xpath = "//a[contains(text(),'Home Interiors')]")
    private WebElement homeInteriorsMenu;

    @FindBy(xpath = "//a[contains(text(),'Home interior design services') or contains(.,'Home interior design services')]")
    private WebElement homeInteriorDesignServicesLink;

    @FindBy(id = "book-slot")
    private WebElement bookSlotButton;

    public void hoverOnHomeInteriors() {
        Actions actions = new Actions(driver);
        wait.until(ExpectedConditions.visibilityOf(homeInteriorsMenu));
        actions.moveToElement(homeInteriorsMenu).perform();
    }

    public void clickHomeInteriorDesignServices() {
        wait.until(ExpectedConditions.elementToBeClickable(homeInteriorDesignServicesLink));
        homeInteriorDesignServicesLink.click();

        // Wait for a new tab or page load - assume it opens a new page
        wait.until(d -> ((WebDriver)driver).getTitle() != null);
    }

    public FormFillPage goToFormFillPage() {
        // try clicking a link/button that navigates to FormFillPage; fallback to bookSlot button
        try {
            if (bookSlotButton != null && bookSlotButton.isDisplayed()) {
                bookSlotButton.click();
            }
        } catch (Exception e) {
            // ignore
        }
        return new FormFillPage(driver);
    }

    public void clickBookSlotDirectly() {
        wait.until(ExpectedConditions.elementToBeClickable(bookSlotButton));
        bookSlotButton.click();
    }
}
