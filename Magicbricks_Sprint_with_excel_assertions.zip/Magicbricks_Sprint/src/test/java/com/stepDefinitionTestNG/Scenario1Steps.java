package com.stepDefinitionTestNG;

import com.setup.DriverManager;
import com.pages.FormFillPage;
import com.pages.HomePage;
import com.parameters.ExcelUtils;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.testng.Assert;
import com.stepDefinitionTestNG.Hooks;

public class Scenario1Steps {
    private WebDriver driver = DriverManager.getDriver();
    private HomePage homepage = new HomePage(driver);
    private FormFillPage formPage = new FormFillPage(driver);
    private ExcelUtils excel;

    @When("I hover over Home Interiors")
    public void i_hover_over_home_interiors() {
        homepage.hoverOnHomeInteriors();
    }

    @When("I click on Home interior design services")
    public void i_click_on_home_interior_design_services() {
        homepage.clickHomeInteriorDesignServices();
    }

    @When("I fill in the form with detail at {int} in {string}")
    public void i_fill_in_the_form_with_detail_at_in(Integer rowNum, String sheetName) throws Exception {
        // Initialize ExcelUtils using the repo Hooks helper which provides excel location
        String excelPath = Hooks.getExcelLocation();
        excel = new ExcelUtils(excelPath, sheetName);

        // Read name and phone from Excel (columns 0 and 1)
        String username = excel.getCellData(rowNum, 0);
        String phone = excel.getCellData(rowNum, 1);

        // Enter the data into form
        formPage.enterUserName(username);
        formPage.enterPhone(phone);

        // Assertions - verify that inputs contain the expected values
        String enteredName = driver.findElement(By.id("user-name")).getAttribute("value");
        String enteredPhone = driver.findElement(By.id("phone")).getAttribute("value");

        Assert.assertEquals(enteredName.trim(), username.trim(), "Entered name should match Excel value");
        Assert.assertEquals(enteredPhone.replaceAll("\\.0+$","").trim(), String.valueOf(phone).trim(), "Entered phone should match Excel value");
    }

    @When("I click on Book Slot")
    public void i_click_on_book_slot() {
        formPage.clickBookSlot();
    }

    @Then("I wait for OTP entry")
    public void i_wait_for_otp_entry() throws InterruptedException {
        // Give time to receive OTP and for elements to appear
        Thread.sleep(5000);
        // Assert that OTP input is visible (try common ids)
        boolean otpPresent = driver.findElements(By.id("otp")).size() > 0
                || driver.findElements(By.id("otp-input")).size() > 0
                || driver.findElements(By.cssSelector("input[name='otp']")).size() > 0;
        Assert.assertTrue(otpPresent, "OTP input should be present after booking");
    }

    @When("I manually enter the OTP and click Submit")
    public void i_manually_enter_the_otp_and_click_submit() throws InterruptedException {
        // Pause briefly for manual OTP entry
        Thread.sleep(15000);
        try {
            driver.findElement(By.id("otp-submit")).click();
        } catch (Exception e) {
            // no-op if submit not found
        }
    }

    @Then("I should be navigated to the budget selection page")
    public void i_should_be_navigated_to_budget_selection_page() {
        String title = driver.getTitle().toLowerCase();
        String url = driver.getCurrentUrl().toLowerCase();
        Assert.assertTrue(title.contains("budget") || url.contains("budget") || url.contains("budget-selection"), "Should navigate to budget selection page");
    }
}
