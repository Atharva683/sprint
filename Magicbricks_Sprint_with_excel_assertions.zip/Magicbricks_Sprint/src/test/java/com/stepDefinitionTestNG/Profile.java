package com.stepDefinitionTestNG;

import com.setup.DriverManager;
import com.pages.*;
import com.parameters.ConfigReader;
import com.parameters.ExcelUtils;

import io.cucumber.java.en.*;

import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.WebDriver;

public class Profile {
    private WebDriver driver = DriverManager.getDriver();
    private HomePage homepage;
    private ExcelUtils excel;
    
    private String excelPath = Hooks.getExcelLocation();
    
    public Profile() {
		this.driver = Hooks.getDriver();
		this.homepage=new HomePage(driver);
	}
 
    @When("I hover over Home Interiors")
    public void i_hover_over_home_interiors() {
        // Write code here that turns the phrase above into concrete actions
    	homepage.hoverOnHomeInteriors(driver);
    }

    @When("I click on Home interior design services")
    public void i_click_on_home_interior_design_services() {
    	homepage.clickHomeInteriorDesignServices();
    }

    @When("I fill in the form with detail at {int} in {string}")
    public void i_fill_in_the_form_with_detail_at_in(Integer rowNum, String sheetName) throws IOException {
    	excel = new ExcelUtils(excelPath, sheetName);
		String username = excel.getCellData(rowNum, 0);
		String password = excel.getCellData(rowNum, 1);
		
    }

    @When("I click on Book Slot")
    public void i_click_on_book_slot() {
    }

    @When("I manually enter the OTP and click Submit")
    public void i_manually_enter_the_otp_and_click_submit() {
    }

    @When("I select Possesion status and Budget from excel {int}")
    public void i_select_possesion_status_and_budget_from_excel(Integer int1) {
    }

    @When("I click on Submit")
    public void i_click_on_submit() {
    }
    
    @Then("I wait for OTP entry")
    public void i_wait_for_otp_entry() {
    }

    @Then("I should be navigated to the budget selection page")
    public void i_should_be_navigated_to_the_budget_selection_page() {
    }

    @Then("I should see a confirmation message {string}")
    public void i_should_see_a_confirmation_message(String string) {
    }








    


}
