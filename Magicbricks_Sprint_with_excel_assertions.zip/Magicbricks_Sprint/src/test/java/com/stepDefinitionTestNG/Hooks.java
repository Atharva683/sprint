package com.stepDefinitionTestNG;
 
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import org.openqa.selenium.WebDriver;

import com.setup.DriverManager;

import com.parameters.ConfigReader;

import io.cucumber.java.After;

import io.cucumber.java.Before;

import io.cucumber.java.Scenario;
 
public class Hooks {
 
    private static WebDriver driver;

    private static String excelLocation;

    // ==================== Before Scenario =========================

    @Before

    public void setup(Scenario scenario) {

        System.out.println("=============== [BEFORE SCENARIO] ===============");

        System.out.println("Starting Scenario: " + scenario.getName());
 
        driver = DriverManager.getDriver();

        driver.manage().window().maximize();
 
        String url = ConfigReader.getProperty("base.url");

        driver.get(url);

        System.out.println("Browser launched and navigated to: " + url);

        excelLocation = ConfigReader.getProperty("excel.path");

    }
 
    // ==================== After Scenario =========================

    @After

    public void teardown(Scenario scenario) throws InterruptedException {

        System.out.println("=============== [AFTER SCENARIO] ===============");

        System.out.println("Finished Scenario: " + scenario.getName() + " | Status: " + scenario.getStatus());
 
        try {

            if (driver != null) {

                // Capture screenshot only if scenario failed

                if (scenario.isFailed()) {

                    final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);

                    scenario.attach(screenshot, "image/png", "Failure Screenshot");
 
                    String screenshotDir = "target/Reports/screenshots";

                    Files.createDirectories(Paths.get(screenshotDir));

                    String fileName = screenshotDir + "/" + scenario.getName().replaceAll("[^a-zA-Z0-9]", "_") + ".png";
 
                    try (FileOutputStream out = new FileOutputStream(new File(fileName))) {

                        out.write(screenshot);

                    }

                    System.out.println("Failure screenshot saved to: " + fileName);

                }

            }

        } catch (Exception e) {

            System.err.println("Error capturing screenshot: " + e.getMessage());

        } finally {

            DriverManager.quitDriver();

            System.out.println("Browser closed");

        }

    }
 
    public static WebDriver getDriver() {

        return driver;

    }

    public static String getExcelLocation() {

        return excelLocation;

    }
 
}
 