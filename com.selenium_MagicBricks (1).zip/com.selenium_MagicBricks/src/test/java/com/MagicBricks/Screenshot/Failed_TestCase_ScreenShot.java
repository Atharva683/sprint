package com.MagicBricks.Screenshot;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
 
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
 
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
public class Failed_TestCase_ScreenShot {
 
	@Test
 
	public static void Take_Screenshot(WebDriver driver ) {
// 
// 
//		ExtentSparkReporter sparkReporter = new ExtentSparkReporter("C:\\Driver\\extendReport.html");
//		ExtentReports extent = new ExtentReports();		
//		extent.attachReporter(sparkReporter);//log and test exe
////		// Create a test
//		ExtentTest test = extent.createTest("Screenshot Test", "Test to capture screenshot during automation");
////		//ChromeDriver and WebDriverWait
////		System.setProperty("webdriver.chrome.driver", "C:\\Driver\\chromedriver.exe");
//		WebDriverWait wait = new WebDriverWait(driver, 10);
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		try {
//			Thread.sleep(2000);
//			// Save the screenshot to a file
//			//String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
//			
////			  try {
////		            Thread.sleep(2000);
////
////		            // Capture the screenshot as bytes
////		            byte[] src = driver.findElement(By.xpath("//*[@id=\"commentCaptchaErrSignIn\"]"))
////		                    .getScreenshotAs(OutputType.BYTES);
////
////		            // Save the screenshot to a file
////		            String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
////		            File screenshotFile = new File("C:\\failed_screenshots\\ss_" + timestamp + ".png");
////		            screenshotFile.getParentFile().mkdirs(); // Create directory if it doesn't exist
////		            try (FileOutputStream fos = new FileOutputStream(screenshotFile)) {
////		                fos.write(src);
////		            }
//			File src =((TakesScreenshot) driver.findElement(By.xpath("//*[@id=\"commentCaptchaErrSignIn\"]"))).getScreenshotAs(OutputType.FILE);
//			FileUtils.copyFile(src, new File("C:\\failed_screenshots\\ss.png"));
//			test.fail("Test failed: Unable to perform the expected action",
//					MediaEntityBuilder.createScreenCaptureFromPath("C:\\failed_screenshots\\ss.png").build());
//		} catch (Exception e) {
//			// In case of failure, log the error message
//			test.fail("Test failed due to: " + e.getMessage());
//			e.printStackTrace();
//		} finally {
//			extent.flush();
//			driver.quit();
//		}}
	}}
		
	