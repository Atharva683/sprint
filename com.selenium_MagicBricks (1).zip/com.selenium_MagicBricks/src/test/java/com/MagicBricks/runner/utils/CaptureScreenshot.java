package com.MagicBricks.runner.utils;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class CaptureScreenshot {

	 public static void Screenshot(WebDriver driver) throws IOException{
			File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			try {
				File Dest=new File("C:\\driver\\screenshots\\"+timestamp()+" "+ "magicbricks.png");			
				FileUtils.copyFile(src, Dest);
			}
			catch (IOException e)
			{
				System.out.println(e.getMessage()) ;
			}
		}
	 
		public static String timestamp() {
	 
			return new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date(0));
			
		}
	
}
