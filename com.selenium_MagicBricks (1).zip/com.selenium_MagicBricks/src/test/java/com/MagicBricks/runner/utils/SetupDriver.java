package com.MagicBricks.runner.utils;
 
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;

import com.aventstack.extentreports.gherkin.model.Scenario;
 
//import com.microsoft.edge.seleniumtools.EdgeDriver;
 
public class SetupDriver {
 
    public static WebDriver driver;
    static ChromeOptions options;
//    TestContextSetup testContextSetup;
//
//    public SetupDriver(TestContextSetup testContextSetup) {
//        this.testContextSetup = testContextSetup;
//    }
    
    public static WebDriver chromeDriver()  {
        System.setProperty("webdriver.chrome.driver","C:\\driver\\chromedriver.exe");
         options = new ChromeOptions();
        driver = new ChromeDriver(options);
        options.addArguments("--disable-notifications");
        driver.manage().window().maximize();
        System.out.println("Launching Chrome Browser");
        driver.get("https://www.magicbricks.com/");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        return driver;
    }
 

    public static WebDriver edgeDriver() {
        System.setProperty("webdriver.edge.driver", "C:\\Users\\ACBALASA\\Downloads\\edgedriver_win64 (1)\\msedgedriver.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        System.out.println("Launching Edge Browser");
        driver.get("https://www.magicbricks.com/");      
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        return driver;
    }
    public static void teardown() throws Exception {
    	System.out.println("i m in teardown");
    	Thread.sleep(5000);
        driver.close();
        driver.quit();
    }
    
    
    public static void Screenshot(WebDriver driver) throws IOException{
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			File Dest=new File("C:\\driver\\screenshots\\"+timestamp()+" "+ "magicbricks.png");			
			FileUtils.copyFile(src, Dest);
		}
		catch (IOException e)
		{
			System.out.println(e.getMessage()) ;
		}
	}
 
	public static String timestamp() {
 
		return new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date(0));
		
	}

    
//	public void AddScreenshot(Scenario scenario) throws IOException
//    {
//        WebDriver driver =testContextSetup.testBase.WebDriverManager();
//        if(scenario.isFailed())
//        {
//        File sourcePath=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
//        byte[] fileContent = FileUtils.readFileToByteArray(sourcePath);
//        scenario.attach(fileContent, "image/png", "image");
//        }
// }
    
    
}
