package com.runner;
 
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.DataProvider;
 
import com.MagicBricks.runner.utils.SetupDriver;
 
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
 
//import org.testng.annotations.AfterSuite;
//import org.testng.annotations.DataProvider; 
//@CucumberOptions(
//		strict = true, 
//      features = {"src/test/resources/Features"}, 
//      glue = {"com.stepdefinations"},
//    monochrome = true,
//	  tags = {"@HomeInterior"}
//		
//		)
 
@CucumberOptions(
	    features = {"src/test/resources/Features"},
	    glue = {"com.stepdefinations"},
	    plugin= {"pretty",
	        "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"  
	    },
	    monochrome = true,
	    tags = "@HomeInterior" // Default value; overridden by command-line arguments
	)
 
public class TestRunnerTestNG extends AbstractTestNGCucumberTests {
//	@DataProvider(parallel = true)
//
//	public Object[][] scenarios() {
//		return super.scenarios();
//	}
//
//	@AfterSuite
//	public void Search() throws Exception {
//		SetupDriver.chromeDriver();
//		
//	}
}

