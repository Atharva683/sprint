package com.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.MagicBricks.runner.utils.SetupDriver;

import io.cucumber.datatable.DataTable;

public class FullHomeInteriorPage {
	
	WebDriver driver;
	Actions action;
	public FullHomeInteriorPage(WebDriver driver)
	{
		this.driver = driver;
		this.action = new Actions(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath=("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]"))
	WebElement homeinterior;
	
	@FindBy(xpath=("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]/div/div/div[3]/ul/li[4]/a"))
	WebElement homeinterior_cal;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div/div[1]/div/div[2]/div[1]/label"))
	WebElement flat_type;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div/div[1]/div/div[2]/div[1]/label/div[2]/div[1]/label/span"))
	WebElement large;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div/div[2]/button"))
	WebElement next_button;
	
	@FindBy(xpath=("//*[@id=\"user-name\"]"))
	WebElement name_for_home_interior_cal;
	
	@FindBy(xpath=("//*[@id=\"phone\"]"))
	WebElement mob_no_home_interior_cal;
	
	@FindBy(xpath=("//*[@id=\"email\"]"))
	WebElement email_home_interior_cal;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div/div[2]/button"))
	WebElement get_estimate_button;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div/div[2]/button"))
	WebElement verify_otp_for_home_cal;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[2]/div[2]/ul/li[1]/label"))
	WebElement Your_interiors_requirements_is_for;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[3]/div[2]/ul/li[1]/label"))
	WebElement When_do_you_plan_to_get_the_interiors_done;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[4]/div[2]/div"))
	WebElement select_city;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[4]/div[2]/ul/li[3]"))
	WebElement city_selection_delhi;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div/div[2]/button"))
	WebElement Get_free_estimate_button;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div/div/div/div[4]/button"))
	WebElement get_estimate_on_email;
	
	@FindBy(xpath=("//*[@id=\"ptch-pop-name-1\"]"))
	WebElement enter_email_in_popup;
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div/div[2]/div/div/div/button"))
	WebElement get_now_button;
	
		public void hover_Interior() throws Exception {
			Thread.sleep(2000);
			//driver.findElement(By.xpath("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]")).click();
			//WebElement homeinterior = driver.findElement(By.xpath("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]"));
			//WebElement homeinterior = driver.findElement(By.xpath("//a[@class='mb-header__sub__tabs__link js-menu-link active']"));
//			Actions action = new Actions(driver);
			action.moveToElement(homeinterior).build().perform();
			Thread.sleep(3000);
			SetupDriver.Screenshot(driver);
			
		}
		
		public void full_Home_Intr_Calc() throws InterruptedException {
			
			//WebElement homeinterior_cal = driver.findElement(By.xpath("//*[@id='commercialIndex']/header/section[2]/div/ul/li[5]/div/div/div[3]/ul/li[4]/a"));
			action.moveToElement(homeinterior_cal).click().build().perform();
			Thread.sleep(2000);
			 Object[] windowHandles = driver.getWindowHandles().toArray();
			    driver.switchTo().window((String) windowHandles[1]);
			    // Print the title of the new window for verification
			    System.out.println("Switched to new window: " + driver.getTitle());
			  
		}
		
		public void select_BHK_type() {
			
//			driver.findElement(By.name("bhks")).click();
			//select flat type
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div/div[2]/div[1]/label")).click();
			flat_type.click();
			//select large or small
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div/div[2]/div[1]/label/div[2]/div[1]/label/span")).click();
			large.click();
		}
		public void next_button() {
			//next_button_for_flat
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/button")).sendKeys(Keys.ENTER);
			next_button.sendKeys(Keys.ENTER);
		}
		public void fill_field_on_page(DataTable details) throws Exception {
			List<List<String>> data = details.asLists();
			WebDriverWait wait=new WebDriverWait(driver,3);
			 for (int i = 1; i < data.size(); i++) {
				 List<String> credential = data.get(i);
				 String name = credential.get(0);  // First column - email
		        String email= credential.get(1);
		        String number = credential.get(2);
		        Thread.sleep(2000);
//		        name_for_home_interior_cal.clear();
//		        mob_no_home_interior_cal.clear();
//		        email_home_interior_cal.clear();
		        name_for_home_interior_cal.sendKeys(name);
		        mob_no_home_interior_cal.sendKeys(number);
		        email_home_interior_cal.sendKeys(email);
		        
			 }
			
			//driver.findElement(By.xpath("//*[@id=\"user-name\"]")).sendKeys("Achal");
			//name_for_home_interior_cal.sendKeys("Achal");
			//mobile_no
		//	mob_no_home_interior_cal.sendKeys("8080454391");
			//driver.findElement(By.xpath("//*[@id=\"phone\"]")).sendKeys("8080454391");
			//email
			//driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("achalbhujbal2003@gmail.com");
			//email_home_interior_cal.sendKeys("achalbhujbal2003@gmail.com");
			//get estimate button
			Thread.sleep(1000);
			get_estimate_button.click();
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/button")).click();
		}
		
		public void verify_otp() throws InterruptedException {
			Thread.sleep(25000);
			//verify_otp_for_home_cal
			verify_otp_for_home_cal.click();
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/button")).click();
		}
		
		public void select_option_given_on_page() {
			//Your interiors requirements is for (self use)
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[2]/div[2]/ul/li[1]/label")).click();
			Your_interiors_requirements_is_for.click();
			//When do you plan to get the interiors done?(within month)
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[3]/div[2]/ul/li[1]/label")).click();
			When_do_you_plan_to_get_the_interiors_done.click();
			//select city
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[4]/div[2]/div")).click();
			select_city.click();
			//city selection delhi
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div[4]/div[2]/ul/li[3]")).click();	
			city_selection_delhi.click();
			//Get free estimate button
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/button")).click();
			Get_free_estimate_button.click();
		}
		
		public void on_estimation_page() {
//	show details
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div/div[3]/div[2]/div[3]/span")).click();
//			get estimate on email
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div/div[4]/button")).click();
			get_estimate_on_email.click();
			//enter email in popup
			//driver.findElement(By.xpath("//*[@id=\"ptch-pop-name-1\"]")).sendKeys("achalbhujbal2003@gmail.com");
			enter_email_in_popup.sendKeys("achalbhujbal2003@gmail.com");
			//get now button
			//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/div/div/div/button")).click();
			get_now_button.click();
			
		}
		
//		public void success_message() {
//			System.out.println("final estimation done");
//		}
}
