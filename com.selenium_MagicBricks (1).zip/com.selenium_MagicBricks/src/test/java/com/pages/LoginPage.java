package com.pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import org.openqa.selenium.OutputType;
import com.MagicBricks.Screenshot.*;
import com.MagicBricks.runner.utils.SetupDriver;


public class LoginPage {
	WebDriver driver;
	Actions action;
	public LoginPage(WebDriver driver)
	{
		this.driver = driver;
		this.action = new Actions(driver);
		PageFactory.initElements(driver, this);
	}

	public void go_to_login() throws InterruptedException {
		// TODO Auto-generated method stub
		driver.get("https://accounts.magicbricks.com/userauth/login"); // Navigate to the website
		Thread.sleep(3000);
	}
	public void enter_mobile() throws InterruptedException, IOException {
		
		WebElement mob_no =driver.findElement(By.xpath("//*[@id=\"emailOrMobileLable\"]"));
		action.click(mob_no).sendKeys("98765432").perform();
		ExtentSparkReporter sparkReporter = new ExtentSparkReporter("C:\\Driver\\extendReport.html");
		ExtentReports extent = new ExtentReports();		
		extent.attachReporter(sparkReporter);
		ExtentTest test = extent.createTest("Screenshot Test", "Test to capture screenshot during automation");
//		mob_no.click();
//		mob_no.sendKeys("9087654321");
//		Thread.sleep(2000);
//		driver.findElement(By.id("//*[@id=\"emailOrMobileLable\"]")).sendKeys("9087654321");
		//SetupDriver.Screenshot(driver);
		File src =((TakesScreenshot) driver.findElement(By.xpath("//*[@id=\"firstLoginDiv\"]/div[3]/div[1]"))).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\failed_screenshots\\ss.png"));
		test.fail("Test failed: Unable to perform the expected action",
				MediaEntityBuilder.createScreenCaptureFromPath("C:\\failed_screenshots\\ss.png").build());
	}



	public void Take_screenshot_invlaid_login() throws IOException, InterruptedException {
	driver.findElement(By.xpath("//*[@id=\"btnStep1\"]")).click();
		//Failed_TestCase_ScreenShot.Take_Screenshot( driver );
		

	}}
