package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.MagicBricks.runner.utils.SetupDriver;

public class OneBHKdesignpage {
	WebDriver driver;
	Actions action;

		public OneBHKdesignpage(WebDriver driver) {
			this.driver = driver;
			this.action = new Actions(driver);
			PageFactory.initElements(driver, this);
	}
		@FindBy(xpath=("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]"))
		WebElement homeinterior;
		
		@FindBy(xpath=("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]/div/div/div[2]/ul/li[1]/a"))
		WebElement oneBHK_design;
		
		@FindBy(xpath=("//*[@id=\"intsrpbhkPages\"]/div[1]/div/div/div[2]/div"))
		WebElement select_city_onebhk;
		
		@FindBy(xpath=("//*[@id=\"intsrpbhkPages\"]/div[1]/div[1]/div/div[2]/div[2]/div[2]/div[2]/ul/li[2]/label"))
		WebElement delhicity;
		
		@FindBy(xpath=("//*[@id=\"intsrpbhkPages\"]/div[1]/div/div/div[4]/div"))
		WebElement price;
		
		@FindBy(xpath=("//*[@id=\"intsrpbhkPages\"]/div[1]/div[1]/div/div[4]/div[2]/div[2]/div[2]/ul/li[2]/label"))
		WebElement fivetenlacs;

		@FindBy(xpath=("//*[@id=\"intsrpbhkPages\"]/div[3]/div[1]/div/div[1]/div/span"))
		WebElement readmore;
		
		@FindBy(xpath=("//*[@id=\"intsrpbhkPages\"]/div[3]/div[1]/div/div[2]/div[1]/div[2]/div[2]/div/span[1]"))
		WebElement getquote;
		
		@FindBy(xpath=("//*[@id=\"int-contact-popup\"]/div/div[2]/div[2]/div/ul/li[1]/label"))
		WebElement banglorecity;
		
		@FindBy(xpath=("//*[@id=\"int-contact-popup\"]/div/div[2]/div[3]/div"))
		WebElement continue_getquote;
		
		@FindBy(xpath=("//*[@id=\"user-name\"]"))
		WebElement name_fill;
		
		@FindBy(xpath=("//*[@id=\"phone\"]"))
		WebElement phone_fill;
		
		@FindBy(xpath=("//*[@id=\"email\"]"))
		WebElement email_full;
		
		@FindBy(xpath=("//*[@id=\"int-contact-popup\"]/div/div[3]/button"))
		WebElement submit_fill;
		
		@FindBy(xpath=("//*[@id=\"int-contact-popup\"]/div/div[3]/button"))
		WebElement check_otp;
		
		public void hover_Interior() throws Exception {
			Thread.sleep(2000);
			
			//WebElement homeinterior = driver.findElement(By.xpath("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]"));
			action.moveToElement(homeinterior).build().perform();
			Thread.sleep(3000);			
			
		}
		
		public void oneBhkdesign() throws InterruptedException {
			
			//WebElement oneBHK_design = driver.findElement(By.xpath("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]/div/div/div[2]/ul/li[1]/a"));
			action.moveToElement(oneBHK_design).click().build().perform();
			Thread.sleep(2000);
			 Object[] windowHandles = driver.getWindowHandles().toArray();
			    driver.switchTo().window((String) windowHandles[1]);

			    // Print the title of the new window for verification
			    System.out.println("Switched to new window: " + driver.getTitle());
			  
		}
		
		public void filters() throws InterruptedException {
			//select city
			Thread.sleep(2000);
			//driver.findElement(By.xpath("//*[@id=\"intsrpbhkPages\"]/div[1]/div/div/div[2]/div")).click();
			select_city_onebhk.click();
			//delhi
						
			//driver.findElement(By.xpath("//*[@id=\"intsrpbhkPages\"]/div[1]/div[1]/div/div[2]/div[2]/div[2]/div[2]/ul/li[2]/label")).click();
			delhicity.click();
			
			//pricerange
			//WebElement price=driver.findElement(By.xpath("//*[@id=\"intsrpbhkPages\"]/div[1]/div/div/div[4]/div"));
			action.moveToElement(price).click().build().perform();
			//5-10lacs
			//driver.findElement(By.xpath("//*[@id=\"intsrpbhkPages\"]/div[1]/div[1]/div/div[4]/div[2]/div[2]/div[2]/ul/li[2]/label")).click();			
			fivetenlacs.click();
			//readmore
			//driver.findElement(By.xpath("//*[@id=\"intsrpbhkPages\"]/div[3]/div[1]/div/div[1]/div/span")).click();
			readmore.click();
			
		}
		
		public void get_qoute() {
			//getqoute
			//driver.findElement(By.xpath("//*[@id=\"intsrpbhkPages\"]/div[3]/div[1]/div/div[2]/div[1]/div[2]/div[2]/div/span[1]")).click();		
			getquote.click();
			//banglore
			//driver.findElement(By.xpath("//*[@id=\"int-contact-popup\"]/div/div[2]/div[2]/div/ul/li[1]/label")).click();
			banglorecity.click();
			//continue
			//driver.findElement(By.xpath("//*[@id=\"int-contact-popup\"]/div/div[2]/div[3]/div")).click();			
			continue_getquote.click();
		}
		
		public void fill_required_info() throws Exception {
			//name
			Thread.sleep(2000);
			//driver.findElement(By.xpath("//*[@id=\"user-name\"]")).sendKeys("Vinay");
			name_fill.sendKeys("Vinay");
			//mob_no
			//driver.findElement(By.xpath("//*[@id=\"phone\"]")).sendKeys("9087654321");
			phone_fill.sendKeys("9087654321");
			//email
			//driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("abc@gmail.com");
			
			email_full.sendKeys("abc@gmail.com");
			
			//submit button
			//driver.findElement(By.xpath("//*[@id=\"int-contact-popup\"]/div/div[3]/button")).click();
			
			submit_fill.click();
			
		}
		
		public void check_otp() {
			//driver.findElement(By.xpath("//*[@id=\"int-contact-popup\"]/div/div[3]/button")).click();	
			check_otp.click();
		}
}
