package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.MagicBricks.runner.utils.SetupDriver;

public class KitchenWardrobePage {
	WebDriver driver;
	Actions action;
	public KitchenWardrobePage(WebDriver driver)
	{
		this.driver = driver;
		this.action = new Actions(driver);
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath=("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]"))
	WebElement homeinterior;
	
	@FindBy(xpath=("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]/div/div/div[3]/ul/li[5]/a"))
	WebElement kitchen_cal;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div[2]/div[1]/div/div[2]/div[1]/label/div/div"))
	WebElement layout_kitchen;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div[2]/div[2]/div/div[2]/div[2]/label"))
	WebElement selected_layout;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div[2]/div[3]/button"))
	WebElement Layout_next;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div[2]/div[1]/div/div[1]/div[2]/button[2]"))
	WebElement number;
	
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div[2]/div[1]/div/div[3]/div[2]/label/div[1]"))
	WebElement size_medium;
	 
	@FindBy(xpath=("//*[@id=\"root\"]/div/div[2]/div[2]/div[2]/button"))
	WebElement next_button_size;
	
	public void hover_Interior() throws Exception {
		Thread.sleep(2000);
		//driver.findElement(By.xpath("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]")).click();
		WebElement homeinterior = driver.findElement(By.xpath("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]"));
		//WebElement homeinterior = driver.findElement(By.xpath("//a[@class='mb-header__sub__tabs__link js-menu-link active']"));
//		Actions action = new Actions(driver);
		action.moveToElement(homeinterior).build().perform();
		Thread.sleep(3000);
		
	}
	
	public void kitchen_Calc() throws InterruptedException {		
		//WebElement kitchen_cal = driver.findElement(By.xpath("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]/div/div/div[3]/ul/li[5]/a"));
		action.moveToElement(kitchen_cal).click().build().perform();
		Thread.sleep(2000);
		 Object[] windowHandles = driver.getWindowHandles().toArray();
		    driver.switchTo().window((String) windowHandles[1]);
		    // Print the title of the new window for verification
		    System.out.println("Switched to new window: " + driver.getTitle());	  
	}
	
	public void select_size_layout() throws InterruptedException {
		Thread.sleep(2000);
		//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div[1]/div/div[2]/div[1]/label/div/div")).click();
		
		layout_kitchen.click();
		//Thread.sleep(2000);
		//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div[2]/div/div[2]/div[2]/label")).click();
		
		selected_layout.click();
		
		//next button
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div[3]/button")).click();
		Layout_next.click();
	}
	
	public void select_size() throws Exception {
	//WebElement 	size=driver.findElements(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div[1]/div/div[3]/div[2]/label/div[1]"));
		
		//size
//		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div[1]/div/div[1]/div[2]")).click();
//		Thread.sleep(3000);
		Thread.sleep(2000);
		//number
		//WebElement number=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div[1]/div/div[1]/div[2]/button[2]"));
		Thread.sleep(2000);
		action.moveToElement(number).click().perform();
		//size_medium
		//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div[1]/div/div[3]/div[2]/label/div[1]")).click();
	   size_medium.click();
		Thread.sleep(2000);
		//driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div[2]/button")).click();
		
		next_button_size.click();
		
	}
	
}
