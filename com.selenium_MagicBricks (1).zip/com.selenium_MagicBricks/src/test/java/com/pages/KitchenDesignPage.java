package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.MagicBricks.runner.utils.SetupDriver;

public class KitchenDesignPage {
//	WebDriver driver = SetupDriver.chromeDriver();
//	Actions action = new Actions(driver);
	WebDriver driver;
	Actions action;
	public KitchenDesignPage(WebDriver driver)
	{
		this.driver = driver;
		this.action = new Actions(driver);
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath=("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]"))
	WebElement homeinterior;
	
	@FindBy(xpath=("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]/div/div/div[1]/ul/li[1]/a"))
	WebElement kitchen_design;

	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div/div/div[2]/div"))
	WebElement style;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[2]/div[2]/div[2]/div[2]/ul/li[2]/label"))
	WebElement luxury;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[2]/div[2]/div[1]"))
	WebElement closestyle;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div/div/div[3]/div"))
	WebElement size;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[3]/div[2]/div[2]/div[2]/ul/li[2]/label"))
	WebElement mediumsize;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[3]/div[2]/div[1]"))
	WebElement close_size;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[4]/div[1]"))
	WebElement kitchen_layout;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[4]/div[2]/div[2]/div[2]/ul/li[1]/label"))
	WebElement straight;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[4]/div[2]/div[1]"))
	WebElement close_layout;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[5]/div[1]"))
	WebElement floormaterial;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[5]/div[2]/div[2]/div[2]/ul/li[2]/label"))
	WebElement ceramic;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[5]/div[2]/div[1]"))
	WebElement close_floor;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div/div/div[6]/div"))
	WebElement counter_colour;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[6]/div[2]/div[2]/div[2]/ul/li[2]/label"))
	WebElement grey_color;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[6]/div[2]/div[1]"))
	WebElement close_color;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[7]/div"))
	WebElement cabinet;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[7]/div[2]/div[2]/div[2]/ul/li[1]/label"))
	WebElement glass_font;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[7]/div[2]/div[1]"))
	WebElement close_cabinet;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[8]/div[1]"))
	WebElement finish;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[8]/div[2]/div[2]/div[2]/ul/li[1]/label"))
	WebElement matt;
	
	@FindBy(xpath=("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[8]/div[2]/div[1]"))
	WebElement click_finish;
	
		public void hover_Interior() throws Exception {
			Thread.sleep(2000);
			//WebElement homeinterior = driver.findElement(By.xpath("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]"));		
			action.moveToElement(homeinterior).build().perform();
			Thread.sleep(3000);		
		}
		
		public void kitchen_design_window() throws InterruptedException {
			
			//WebElement kitchen_design = driver.findElement(By.xpath("//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[5]/div/div/div[1]/ul/li[1]/a"));
			action.moveToElement(kitchen_design).click().build().perform();
			Thread.sleep(2000);
			 Object[] windowHandles = driver.getWindowHandles().toArray();
			    driver.switchTo().window((String) windowHandles[1]);
			    // Print the title of the new window for verification
			    System.out.println("Switched to new window: " + driver.getTitle());
			  
		}
		
		public void apply_filters() throws InterruptedException {
			//style
			Thread.sleep(2000);
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div/div/div[2]/div")).click();
			style.click();
			//luxury
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[2]/div[2]/div[2]/div[2]/ul/li[2]/label")).click();
			luxury.click();
			//closestyle
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[2]/div[2]/div[1]")).click();
			closestyle.click();
			//size
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div/div/div[3]/div")).click();
			size.click();
			//mediumsize
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[3]/div[2]/div[2]/div[2]/ul/li[2]/label")).click();
			mediumsize.click();
			//close_size
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[3]/div[2]/div[1]")).click();
			close_size.click();
			//kitchen_layout
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[4]/div[1]")).click();
			kitchen_layout.click();
			//straight
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[4]/div[2]/div[2]/div[2]/ul/li[1]/label")).click();
			straight.click();
			//close_layout
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[4]/div[2]/div[1]")).click();
			close_layout.click();
			//floormaterial
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[5]/div[1]")).click();
			floormaterial.click();
			//ceramic
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[5]/div[2]/div[2]/div[2]/ul/li[2]/label")).click();
			ceramic.click();
			//close_floor
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[5]/div[2]/div[1]")).click();
			close_floor.click();
			//counter_colour
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div/div/div[6]/div")).click();
			counter_colour.click();
			//grey_color
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[6]/div[2]/div[2]/div[2]/ul/li[2]/label")).click();
			grey_color.click();
			//close_color
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[6]/div[2]/div[1]")).click();
			close_color.click();
			//cabinet
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[7]/div")).click();
			cabinet.click();
			//glass_font
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[7]/div[2]/div[2]/div[2]/ul/li[1]/label")).click();
			glass_font.click();
			//close_cabinet
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[7]/div[2]/div[1]")).click();
			close_cabinet.click();
			//finish
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[8]/div[1]")).click();
			finish.click();
			//matt
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[8]/div[2]/div[2]/div[2]/ul/li[1]/label")).click();
			matt.click();
			//click_finish
			//driver.findElement(By.xpath("//*[@id=\"id_dirsp\"]/div[1]/div[1]/div/div[8]/div[2]/div[1]")).click();
			click_finish.click();
		
		}
		
		

}
