package com.stepdefinations;

import com.MagicBricks.runner.utils.SetupDriver;
import com.pages.KitchenDesignPage;
import com.pages.KitchenWardrobePage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class KitchenDesign {
	public static KitchenDesignPage kitchendesign = new KitchenDesignPage(SetupDriver.chromeDriver());
	
	@Given("User is on home interior page")
	public void hover_on_interior() throws Exception {
		kitchendesign.hover_Interior();
	}
	
	
	@Then("User have to go on kitchen design ideas window")
	public void go_on_kitchen_design() throws Exception {
		kitchendesign.kitchen_design_window();
	}
	
	@Then("apply all filters")
	public void filters() throws InterruptedException {
		kitchendesign.apply_filters();
	}
}
