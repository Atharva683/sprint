package com.stepdefinations;

import com.MagicBricks.runner.utils.SetupDriver;
import com.pages.FullHomeInteriorPage;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class FullHomeInterior {
	
	private static final FullHomeInteriorPage interior = new FullHomeInteriorPage(SetupDriver.edgeDriver());
	
	@Given("I am on the Full Home Interior Cost Calculator page")
	public void Full_Home_Interior_Cost_Calculator_page() throws Exception {
		System.out.println(" i am on the Full Home Interior Cost Calculator page ");
		interior.hover_Interior();		
	}
	
	@Then("click on Full Home Interior Cost under Full Home Interior Cost")
	public void Full_Home_Interior_Cost() throws InterruptedException {		
		interior.full_Home_Intr_Calc();		
	}
	
	 @When("user can see the input fields for property details I should see options to select the BHK type after selecting 1BHK I should see options Small and Large and selected one from them")
	 public void Select_type() {
		 interior.select_BHK_type();
	 }
	 
	 @Then("user must click on the Next button after this we can go on  Price Estimate is almost ready page")
	 public void click_next_button() {
		 interior.next_button();
	 }
	 
	 @Then("user have to fill the field on the page and click on get Estimate")
	 public void fill_field(DataTable details) throws Exception {
		 interior.fill_field_on_page(details);
	 }
	 
	 @Then("user have to enter otp manully and click on verify otp buttoon")
	 public void verify_otp() throws InterruptedException {
		 interior.verify_otp();
	 }
	 
	 @Then("user must have to select fields given on the page")
	 public void select_options() {
		 interior.select_option_given_on_page();
	 }
	 
	 @Then("user will see estimated cost for home")
	 public void get_estimate() {
		 interior.on_estimation_page();
	 }
	 
//	 @Then("new pop i open for Great You will receive the Estimated Cost on email ID achalbhujbal2003@gmail.com ")
//	 public void success() {
//		 interior.success_message();
//	 }
	 
}
