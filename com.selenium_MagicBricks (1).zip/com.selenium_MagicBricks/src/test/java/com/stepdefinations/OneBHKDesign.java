package com.stepdefinations;

import com.MagicBricks.runner.utils.SetupDriver;
import com.pages.FullHomeInteriorPage;
import com.pages.KitchenDesignPage;
import com.pages.OneBHKdesignpage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class OneBHKDesign {
	public static OneBHKdesignpage oneBhk = new OneBHKdesignpage(SetupDriver.chromeDriver());

	@Given("User is on the  Home Interior  page")
	public void Full_Home_Interior_Cost_Calculator_page() throws Exception {
		System.out.println(" i am on the Full Home Interior Cost Calculator page ");
		oneBhk.hover_Interior();
		
	}
	
	@Then("User have to go on 1BHK interior design")
	public void Full_Home_Interior_Cost() throws InterruptedException {
		
		oneBhk.oneBhkdesign();
		
	}
	
	@And("Apply filters like city and range")
	public void apply_filter() throws InterruptedException {
		oneBhk.filters();
	}
	
	@Then("Click on get qoute and filled the information on the popup")
	public void get_quote_Popup() {
		oneBhk.get_qoute();
	}

	@Then("On next popup fill the required information")
	public void fill_info() throws Exception {
		oneBhk.fill_required_info();
	}
	
	@Then("Check Otp is valid or not")
	public void check_otp() {
		oneBhk.check_otp();
	}

}
