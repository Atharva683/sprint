package com.stepdefinations;

import com.MagicBricks.runner.utils.SetupDriver;
import com.pages.FullHomeInteriorPage;
import com.pages.KitchenWardrobePage;
import com.pages.OneBHKdesignpage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class KitchenWardrobe {
	public static KitchenWardrobePage kitchenwardrobe  = new KitchenWardrobePage(SetupDriver.chromeDriver());
	
	//public static KitchenWardrobePage oneBhk = new KitchenWardrobePage(SetupDriver.chromeDriver());

	@Given("I am on the home interior page")
	public void Full_Home_Interior_Cost_Calculator_page() throws Exception {
		kitchenwardrobe.hover_Interior();		
	}
	
	@Then("click on kitchen wardrobe calculator")
	public void kitchen_calculator_open() throws InterruptedException {
		kitchenwardrobe.kitchen_Calc();
	}
	
	@Then("user have to select layout and size for kitchen and click on next")
	public void select_size() throws InterruptedException {
		kitchenwardrobe.select_size_layout();
	}
	
	@Then("user have to select number and size of wardrobe and click on next")
	public void select_number() throws Exception {
		kitchenwardrobe.select_size();
	}
	
}
