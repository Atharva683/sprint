package com.stepdefinations;

import java.io.IOException;

import com.MagicBricks.runner.utils.SetupDriver;
import com.pages.KitchenWardrobePage;
import com.pages.LoginPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Login {
	public static LoginPage login  = new LoginPage(SetupDriver.chromeDriver());

	@Given("user is on login page")
public void go_to_login() throws InterruptedException {
		
		login.go_to_login();
}
	
	@Then("user enter mobile number")
	public void user_enter_mobile_number() throws InterruptedException, IOException {
		login.enter_mobile();
	   
	}
	@Then("User is entering contact number and try to login and getting error")
	public void Error_exception() throws Exception, InterruptedException {
		login.Take_screenshot_invlaid_login();
	}
}
