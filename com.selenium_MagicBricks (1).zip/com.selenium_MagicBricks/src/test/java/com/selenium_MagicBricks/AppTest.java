package com.selenium_MagicBricks;

public class AppTest {

}
