package com.pages;

import org.openqa.selenium.WebDriver;

public class FormFillPage {

	public FormFillPage(WebDriver driver) {
	}

}
