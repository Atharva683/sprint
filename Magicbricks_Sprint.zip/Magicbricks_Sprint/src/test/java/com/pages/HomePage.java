package com.pages;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.setup.*;


public class HomePage extends BasePage {

	

	 
	
	public HomePage(WebDriver driver) {
		
	}
	
	@FindBy(xpath = "//*[@id='commercialIndex']/header/section[2]/div/ul/li[5]/a")
 	private WebElement homeInteriorsLink;
	
	public void hoverOnHomeInteriors(WebDriver driver) {
		// TODO Auto-generated method stub
		Actions actions = new Actions(driver);
	    actions.moveToElement(homeInteriorsLink).perform();
	}
	
	// PageFactory locator
	@FindBy(xpath = "//*[@id='commercialIndex']/header/section[2]/div/ul/li[5]/div/div/div/ul/li/a")
	private WebElement homeInteriorDesignServicesLink;
	 
	// Method to click
	public FormFillPage clickHomeInteriorDesignServices() {
	    click(homeInteriorDesignServicesLink);
	    ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(tabs.size() - 1));
 
		// Return the new page object
		return new FormFillPage(driver);
 
	}
	
	@FindBy(id = "user-name")
	private WebElement userNameInput;

	public void enterUserName(String userName) throws InterruptedException {
	    type(userNameInput,userName);
	}
}
