package com.parameters;

import com.setup.DriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScreenshotUtil {
    public static String captureScreenshot(String name) {
        try {
            WebDriver driver = DriverManager.getDriver();
            if (driver == null) return null;
            File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            String ts = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String folder = "target/Reports/screenshots/"; new File(folder).mkdirs();
            String safe = name.replaceAll("[^a-zA-Z0-9._-]","_") + "_" + ts + ".png";
            String path = folder + safe; FileUtils.copyFile(src, new File(path)); return path;
        } catch (Exception e) { e.printStackTrace(); return null; }
    }
}
